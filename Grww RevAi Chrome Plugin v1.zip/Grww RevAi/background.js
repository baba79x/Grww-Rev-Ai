/**
 * Service Worker — AI Intelligence Engine
 * Scoring formulas, revenue diagnostics, sales enablement, multi-provider support.
 * v2.3.0 — Dashboard, WhatsApp outreach, SMTP email, user profile.
 */

// ===== RATE LIMITER (Token Bucket) =====
const rateLimiter = {
    tokens: [],       // timestamps of recent requests
    maxRequests: 10,   // default, overridden by settings
    windowMs: 60000,   // 1 minute window

    async load() {
        try {
            const s = await chrome.storage.local.get(['maxRequestsPerMin']);
            if (s.maxRequestsPerMin) this.maxRequests = Math.max(1, Math.min(60, Number(s.maxRequestsPerMin) || 10));
        } catch { /* use defaults */ }
    },

    pruneOld() {
        const cutoff = Date.now() - this.windowMs;
        this.tokens = this.tokens.filter(t => t > cutoff);
    },

    check() {
        this.pruneOld();
        if (this.tokens.length >= this.maxRequests) {
            const oldest = this.tokens[0];
            const waitMs = oldest + this.windowMs - Date.now();
            const waitSec = Math.ceil(waitMs / 1000);
            return { allowed: false, retryAfterSec: waitSec, remaining: 0 };
        }
        return { allowed: true, remaining: this.maxRequests - this.tokens.length };
    },

    consume() {
        this.pruneOld();
        this.tokens.push(Date.now());
        return { remaining: this.maxRequests - this.tokens.length };
    },

    status() {
        this.pruneOld();
        return { remaining: this.maxRequests - this.tokens.length, limit: this.maxRequests };
    }
};


// ===== SECURITY HELPERS =====
const MAX_RESPONSE_BYTES = 512000; // 500KB

function validateBaseUrl(url) {
    if (!url) return true; // empty = use provider default
    try {
        const parsed = new URL(url);
        if (parsed.protocol !== 'https:') {
            throw new Error('Base URL must use HTTPS. HTTP, file://, and other schemes are blocked for security.');
        }
        // Block localhost / private IPs
        const host = parsed.hostname.toLowerCase();
        if (host === 'localhost' || host === '127.0.0.1' || host === '0.0.0.0' || host.startsWith('192.168.') || host.startsWith('10.') || host.endsWith('.local')) {
            throw new Error('Base URL cannot point to localhost or private networks.');
        }
        return true;
    } catch (e) {
        if (e.message.startsWith('Base URL')) throw e;
        throw new Error('Invalid Base URL format.');
    }
}

function validateApiKey(key) {
    if (!key) throw new Error('No API key configured.');
    if (key.length < 10) throw new Error('API key is too short.');
    if (key.length > 256) throw new Error('API key exceeds maximum length (256 characters).');
}


// ===== PROVIDER CONFIGURATIONS =====
const PROVIDERS = {
    openai: {
        name: 'OpenAI',
        baseUrl: 'https://api.openai.com/v1',
        defaultModel: 'gpt-4o-mini',
        buildHeaders: (apiKey) => ({
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${apiKey}`
        }),
        buildBody: (model, systemPrompt, userPrompt, settings) => ({
            model,
            messages: [
                { role: 'system', content: systemPrompt },
                { role: 'user', content: userPrompt }
            ],
            temperature: settings.temperature ?? 0.3,
            max_tokens: settings.maxTokens ?? 6000,
            response_format: { type: 'json_object' }
        }),
        parseResponse: (json) => {
            if (json.error) throw new Error(json.error.message || 'OpenAI API error');
            return json.choices?.[0]?.message?.content;
        }
    },

    anthropic: {
        name: 'Anthropic',
        baseUrl: 'https://api.anthropic.com/v1',
        defaultModel: 'claude-sonnet-4-20250514',
        buildHeaders: (apiKey) => ({
            'Content-Type': 'application/json',
            'x-api-key': apiKey,
            'anthropic-version': '2023-06-01',
            'anthropic-dangerous-direct-browser-access': 'true'
        }),
        buildBody: (model, systemPrompt, userPrompt, settings) => ({
            model,
            system: systemPrompt,
            messages: [{ role: 'user', content: userPrompt }],
            temperature: settings.temperature ?? 0.3,
            max_tokens: settings.maxTokens ?? 6000
        }),
        parseResponse: (json) => {
            if (json.error) throw new Error(json.error.message || 'Anthropic API error');
            return json.content?.find(b => b.type === 'text')?.text;
        }
    },

    gemini: {
        name: 'Google Gemini',
        baseUrl: 'https://generativelanguage.googleapis.com/v1beta',
        defaultModel: 'gemini-2.0-flash',
        buildHeaders: (apiKey) => ({ 'Content-Type': 'application/json', 'x-goog-api-key': apiKey }),
        buildBody: (model, systemPrompt, userPrompt, settings) => ({
            system_instruction: { parts: [{ text: systemPrompt }] },
            contents: [{ parts: [{ text: userPrompt }] }],
            generationConfig: {
                temperature: settings.temperature ?? 0.3,
                maxOutputTokens: settings.maxTokens ?? 6000,
                responseMimeType: 'application/json'
            }
        }),
        getEndpoint: (baseUrl, model) =>
            `${baseUrl}/models/${model}:generateContent`,
        parseResponse: (json) => {
            if (json.error) throw new Error(json.error.message || 'Gemini API error');
            return json.candidates?.[0]?.content?.parts?.[0]?.text;
        }
    },

    digitalocean: {
        name: 'DigitalOcean GenAI',
        baseUrl: 'https://inference.do-ai.run/v1',
        defaultModel: 'deepseek-r1-distill-llama-70b',
        buildHeaders: (apiKey) => ({
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${apiKey}`
        }),
        buildBody: (model, systemPrompt, userPrompt, settings) => ({
            model,
            messages: [
                { role: 'system', content: systemPrompt },
                { role: 'user', content: userPrompt }
            ],
            temperature: settings.temperature ?? 0.3,
            max_tokens: settings.maxTokens ?? 6000
        }),
        parseResponse: (json) => {
            if (json.error) throw new Error(json.error.message || 'DigitalOcean API error');
            let content = json.choices?.[0]?.message?.content;
            if (content) {
                content = content.replace(/<think>[\s\S]*?<\/think>/g, '').trim();
            }
            return content;
        }
    },

    custom: {
        name: 'Custom (OpenAI-compatible)',
        baseUrl: '',
        defaultModel: 'custom-model',
        buildHeaders: (apiKey) => ({
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${apiKey}`
        }),
        buildBody: (model, systemPrompt, userPrompt, settings) => ({
            model,
            messages: [
                { role: 'system', content: systemPrompt },
                { role: 'user', content: userPrompt }
            ],
            temperature: settings.temperature ?? 0.3,
            max_tokens: settings.maxTokens ?? 6000
        }),
        parseResponse: (json) => {
            if (json.error) throw new Error(json.error.message || 'API error');
            return json.choices?.[0]?.message?.content;
        }
    }
};


// ===== MASTER SYSTEM PROMPT =====
const SYSTEM_PROMPT = `You are a senior growth consultant, conversion strategist, technical auditor, and B2B sales intelligence analyst working for Grww. Analyze the provided website data like an elite growth advisor.

Be DIAGNOSTIC, not descriptive. Quantify impact whenever possible. Prioritize revenue implications. Avoid generic recommendations.

ANALYSIS FRAMEWORK — Evaluate across:
1. Conversion System (CTAs, value proposition, forms, friction)
2. SEO & Visibility (meta, headings, content depth, structure)
3. Technical Performance (tech stack, optimization, accessibility)
4. Brand & Trust Signals (social proof, testimonials, case studies)
5. Growth & Budget Indicators (hiring, funding, company maturity)
6. Revenue Leakage Risks (missed conversions, broken funnels, weak nurturing)
7. Sales Opportunity Assessment (how likely this company needs Grww's services)

SCORING SYSTEM — Assign normalized scores (0–100) for each:

A. Conversion Efficiency Score (CES) — based on:
   CTA visibility, CTA contrast, CTA repetition, value proposition clarity, navigation friction, form quality, mobile UX, trust signals

B. SEO Strength Score (SSS) — based on:
   Meta optimization, heading structure, content depth, internal linking, indexability, semantic richness, page speed impact

C. Technical Quality Score (TQS) — based on:
   Performance risk, bundle size, image optimization, CLS risk, accessibility, broken links, legacy tech indicators

D. Sales Opportunity Score (SOS) — based on:
   Growth signals, budget probability, technical debt, conversion gaps, SEO gaps, competitive pressure, product complexity

E. Company Health Index (CHI) = (CES × 0.22) + (SSS × 0.18) + (TQS × 0.20) + (SOS × 0.40)

REVENUE INTELLIGENCE — Estimate potential revenue leakage:
- Severity: Low / Medium / High / Severe
- Provide 3-5 specific causal mechanisms with estimated annual impact ranges
- Frame in dollar ranges when possible

PRIORITY ALERTS — Categorize findings:
- 🔴 Critical (immediate revenue/conversion impact)
- 🟠 Improvement (moderate impact, should fix within 30 days)
- 🟢 Optimized (doing well, maintain)

You MUST respond with valid JSON only — no markdown, no code fences, no explanation. Output this EXACT structure:

{
  "companyName": "string",
  "industry": "string — be specific",
  "website": "string",
  "companySize": "string",
  "founded": "string",
  "headquarters": "string",
  "overview": "string — 2-3 sentences, diagnostic tone",

  "scores": {
    "conversionEfficiency": { "score": 0, "label": "Conversion Efficiency", "details": "string — 2 sentence diagnosis" },
    "seoStrength": { "score": 0, "label": "SEO Strength", "details": "string" },
    "technicalQuality": { "score": 0, "label": "Technical Quality", "details": "string" },
    "salesOpportunity": { "score": 0, "label": "Sales Opportunity", "details": "string" },
    "companyHealth": { "score": 0, "label": "Company Health Index", "details": "string" }
  },

  "keyPeople": [
    { "name": "string", "role": "string", "email": "string | null" }
  ],

  "revenueIntelligence": {
    "severity": "Low | Medium | High | Severe",
    "estimatedLeakRange": "string — e.g. '$50K – $200K / year'",
    "causes": [
      { "cause": "string", "impact": "string — dollar estimate or severity", "fix": "string — what Grww would do" }
    ]
  },

  "alerts": [
    { "severity": "critical | improvement | optimized", "title": "string", "detail": "string — specific, actionable" }
  ],

  "opportunities": [
    {
      "service": "string — specific service Grww offers",
      "problem": "string — what's wrong on their site",
      "estimatedROI": "High | Medium | Low",
      "estimatedBudget": "string",
      "priority": "number — 1 is highest"
    }
  ],

  "competitors": [
    {
      "name": "string",
      "website": "string",
      "description": "string",
      "marketPosition": "Leader | Challenger | Niche | Emerging",
      "strengths": "string",
      "weaknesses": "string",
      "differentiator": "string"
    }
  ],

  "marketAnalysis": {
    "marketSize": "string — dollar figures",
    "growthRate": "string — CAGR",
    "opportunities": ["string"],
    "threats": ["string"],
    "trends": ["string"]
  },

  "keyContacts": [
    {
      "name": "string",
      "title": "string",
      "department": "string",
      "email": "string or null",
      "connectionGuide": "string — specific outreach strategy with talking points"
    }
  ],

  "actionPlan": [
    {
      "step": "string — Title of the action step",
      "description": "string — The 'What': detailed description of the task",
      "justification": "string — The 'Why': rationale and revenue impact",
      "implementation": "string — The 'How': implementation steps",
      "priority": "High | Medium | Low",
      "impact": "High | Medium | Low",
      "timeframe": "string — e.g. 2 weeks"
    }
  ],

  "salesAssist": {
    "coldEmailHook": "string — one-liner hook for cold email subject",
    "linkedinOpener": "string — first message for LinkedIn outreach",
    "keyObjections": ["string — likely objections and how to handle them"],
    "valueAngle": "string — the single most compelling reason they need your services"
  }
}

CRITICAL RULES:
1. Scores MUST be 0–100 integers, realistic (not all 50s, reflect actual website quality)
2. CHI must equal the weighted formula: (CES×0.22)+(SSS×0.18)+(TQS×0.20)+(SOS×0.40)
3. Exactly 5 competitors
4. At least 5 alerts (mix of critical, improvement, optimized)
5. At least 4 service opportunities
6. At least 3 key contacts
7. At least 4 action plan steps
8. Revenue leakage must have 3-5 specific causes
9. Use consulting language — confident, specific, revenue-focused
10. No fluff. Every sentence must be diagnostic or actionable.`;


function buildWebsitePrompt(websiteData) {
    let prompt = `Analyze this company website. Produce a complete intelligence report with scores, revenue diagnostics, and sales opportunities.\n\n`;

    prompt += `=== WEBSITE ===\nURL: ${websiteData.url}\nDomain: ${websiteData.domain}\nTitle: ${websiteData.title}\nMeta: ${websiteData.metaDescription || 'None'}\nKeywords: ${websiteData.metaKeywords || 'None'}\n`;
    if (websiteData.siteName) prompt += `Site Name: ${websiteData.siteName}\n`;

    if (websiteData.headings?.length > 0) {
        prompt += `\n=== HEADINGS ===\n`;
        websiteData.headings.forEach(h => { prompt += `[${h.level}] ${h.text}\n`; });
    }

    if (websiteData.links?.length > 0) {
        prompt += `\n=== NAVIGATION ===\n`;
        websiteData.links.forEach(l => { prompt += `• ${l.text} → ${l.href}\n`; });
    }

    if (websiteData.companySignals) {
        prompt += `\n=== SIGNALS ===\n`;
        const s = websiteData.companySignals;
        prompt += `About:${s.hasAboutPage} Pricing:${s.hasPricingPage} Careers:${s.hasCareersPage} Blog:${s.hasBlog} Products:${s.hasProducts} Services:${s.hasServices} Testimonials:${s.hasTestimonials} Team:${s.hasTeamPage}\n`;
    }

    if (websiteData.socialLinks?.length > 0) {
        prompt += `\n=== SOCIAL ===\n`;
        websiteData.socialLinks.forEach(s => { prompt += `${s.platform}: ${s.url}\n`; });
    }

    if (websiteData.contactInfo) {
        const c = websiteData.contactInfo;
        if (c.emails.length) prompt += `\nEmails: ${c.emails.join(', ')}\n`;
        if (c.phones.length) prompt += `Phones: ${c.phones.join(', ')}\n`;
        if (c.addresses.length) prompt += `Addresses: ${c.addresses.join('; ')}\n`;
    }

    if (websiteData.techStack?.length > 0) {
        prompt += `\n=== TECH STACK ===\n${websiteData.techStack.join(', ')}\n`;
    }

    if (websiteData.structuredData) {
        prompt += `\n=== STRUCTURED DATA ===\n${websiteData.structuredData}\n`;
    }

    if (websiteData.bodyText) {
        prompt += `\n=== CONTENT ===\n${websiteData.bodyText.substring(0, 5000)}\n`;
    }

    prompt += `\nProduce the full JSON intelligence report. Be diagnostic. Quantify revenue impact. Score honestly.`;
    return prompt;
}


// ===== SALES CONTENT PROMPTS =====
const SALES_PROMPTS = {
    coldEmail: (profile, sender, target) => {
        const greeting = target?.name ? `Hi ${target.name.split(' ')[0]},` : `Hi ${profile.companyName} Team,`;
        const signOff = sender?.name ? `\nBest,\n\n${sender.name}\n${sender.role || ''}\n${sender.company || ''}\n${sender.signature || ''}` : `\nBest regards,`;

        return `You are an elite B2B sales copywriter. Write a cold email to ${target?.name || profile.companyName} at ${profile.companyName}.
Context:
- Company Health Score: ${profile.scores?.companyHealth?.score || 'N/A'}/100
- Top issue: ${profile.revenueIntelligence?.causes?.[0]?.cause || 'conversion gaps'}
- Revenue leak: ${profile.revenueIntelligence?.estimatedLeakRange || 'significant'}
- Best service to pitch: ${profile.opportunities?.[0]?.service || 'digital optimization'}
- Sender: ${sender?.name || 'Authorized Consultant'} from ${sender?.company || 'Grww'}

Write a 150-word cold email that:
1. Starts with "${greeting}"
2. Opens with a specific observation about their website
3. Quantifies the problem in revenue terms
4. Proposes a clear next step
5. Sign off EXACTLY with:
${signOff}

Output format (plain text only):
SUBJECT: [subject line]

[email body]`;
    },

    linkedinDM: (profile, sender, target) => {
        const greeting = target?.name ? `Hi ${target.name.split(' ')[0]}` : `Hi there`;
        return `Write a LinkedIn DM sequence to ${target?.name || 'a decision maker'} at ${profile.companyName}.

Context: Health Score ${profile.scores?.companyHealth?.score}/100. Gap: ${profile.revenueIntelligence?.causes?.[0]?.cause}.
Sender: ${sender?.name} (${sender?.role}).

Write 3 short messages:
1. Connection request (max 50 words): Start with "${greeting}". Mention a specific website finding.
2. Follow-up (max 80 words): Value add.
3. Soft pitch (max 80 words).

Sign off each with mere "${sender?.name || 'Me'}" or similar short signature.`;
    },

    auditPitch: (profile, sender, target) => `Create a 1-page audit pitch for ${profile.companyName}.
Target: ${target?.name || 'Executive Team'}
Sender: ${sender?.name || 'Consultant'} (${sender?.company || 'Grww'})
Scores: CES=${profile.scores?.conversionEfficiency?.score}, SSS=${profile.scores?.seoStrength?.score}
Revenue leak: ${profile.revenueIntelligence?.estimatedLeakRange}

Write a professional audit proposal.
1. Executive Summary leading with revenue problem.
2. 3 Critical Findings.
3. Proposed Deep-Dive Audit.
4. Sign off with:
${sender?.name || ''}
${sender?.role || ''}
${sender?.signature || ''}`,

    proposalOutline: (profile, sender, target) => `Create a proposal outline for ${profile.companyName}.
Target: ${target?.name || 'Stakeholders'}
Sender: ${sender?.name || 'Consultant'}

Services: ${profile.opportunities?.map(o => o.service).join(', ')}
Budget: ${profile.opportunities?.map(o => o.estimatedBudget).join(' + ')}

Structure:
1. Executive Summary
2. Scope of Work (Phased)
3. Deliverables
4. Timeline & Investment
5. Why Us

End with a professional sign-off block for ${sender?.name || 'Consultant'}.`,

    whatsappDM: (profile, sender, target) => `
    Context: You are ${sender?.name || 'Consultant'} from ${sender?.company || 'Grww'}.
    Goal: Send a short, punchy WhatsApp message to ${target?.name || 'the founder'} at ${profile.companyName}.
    Tone: Casual, direct, professional. STRICTLY NO EMOJIS.
    Structure:
    1. Casual intro
    2. One specific value prop or observation about their company (${profile.industry})
    3. Low-friction question
    Constraint: Max 50 words. Do NOT use emojis. Do NOT use "👋" or "🚀". Use "-" for lists.
    `
};


// ===== EMAIL SERVICE PROVIDERS =====
const EMAIL_PROVIDERS = {
    sendgrid: {
        name: 'SendGrid',
        buildRequest: (apiKey, from, to, subject, body) => ({
            url: 'https://api.sendgrid.com/v3/mail/send',
            options: {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${apiKey} `,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    personalizations: [{ to: [{ email: to }] }],
                    from: { email: from },
                    subject: subject,
                    content: [{ type: 'text/plain', value: body }]
                })
            }
        }),
        isSuccess: (status) => status >= 200 && status < 300
    },
    mailgun: {
        name: 'Mailgun',
        buildRequest: (apiKey, from, to, subject, body, domain) => {
            const form = new URLSearchParams();
            form.append('from', from);
            form.append('to', to);
            form.append('subject', subject);
            form.append('text', body);
            return {
                url: `https://api.mailgun.net/v3/${domain}/messages`,
                options: {
                    method: 'POST',
                    headers: {
                        'Authorization': 'Basic ' + btoa('api:' + apiKey)
                    },
                    body: form
                }
            };
        },
        isSuccess: (status) => status >= 200 && status < 300
    },
    brevo: {
        name: 'Brevo',
        buildRequest: (apiKey, from, to, subject, body) => ({
            url: 'https://api.brevo.com/v3/smtp/email',
            options: {
                method: 'POST',
                headers: {
                    'api-key': apiKey,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    sender: { email: from },
                    to: [{ email: to }],
                    subject: subject,
                    textContent: body
                })
            }
        }),
        isSuccess: (status) => status >= 200 && status < 300
    },
    custom: {
        name: 'Custom',
        buildRequest: (apiKey, from, to, subject, body, _domain, endpoint) => ({
            url: endpoint,
            options: {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${apiKey}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ from, to, subject, body })
            }
        }),
        isSuccess: (status) => status >= 200 && status < 300
    },
    elasticemail: {
        name: 'Elastic Email',
        buildRequest: (apiKey, from, to, subject, body) => {
            const params = new URLSearchParams();
            params.append('apikey', apiKey);
            params.append('from', from);
            params.append('to', to);
            params.append('subject', subject);
            params.append('bodyText', body);
            return {
                url: 'https://api.elasticemail.com/v2/email/send',
                options: {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: params
                }
            };
        },
        isSuccess: (status) => status >= 200 && status < 300
    },
    postmark: {
        name: 'Postmark',
        buildRequest: (apiKey, from, to, subject, body) => ({
            url: 'https://api.postmarkapp.com/email',
            options: {
                method: 'POST',
                headers: {
                    'X-Postmark-Server-Token': apiKey,
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                body: JSON.stringify({
                    From: from,
                    To: to,
                    Subject: subject,
                    TextBody: body,
                    MessageStream: 'outbound'
                })
            }
        }),
        isSuccess: (status) => status >= 200 && status < 300
    },
    sparkpost: {
        name: 'SparkPost',
        buildRequest: (apiKey, from, to, subject, body) => ({
            url: 'https://api.sparkpost.com/api/v1/transmissions',
            options: {
                method: 'POST',
                headers: {
                    'Authorization': apiKey,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    recipients: [{ address: { email: to } }],
                    content: {
                        from: { email: from },
                        subject: subject,
                        text: body
                    }
                })
            }
        }),
        isSuccess: (status) => status >= 200 && status < 300
    },
    ses: {
        name: 'Amazon SES',
        buildRequest: (apiKey, from, to, subject, body, _domain, _endpoint, region) => {
            const sesRegion = region || 'us-east-1';
            return {
                url: `https://email.${sesRegion}.amazonaws.com/v2/email/outbound-emails`,
                options: {
                    method: 'POST',
                    headers: {
                        'Authorization': `Bearer ${apiKey}`,
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        FromEmailAddress: from,
                        Destination: { ToAddresses: [to] },
                        Content: {
                            Simple: {
                                Subject: { Data: subject },
                                Body: { Text: { Data: body } }
                            }
                        }
                    })
                }
            };
        },
        isSuccess: (status) => status >= 200 && status < 300
    },
    smtp2go: {
        name: 'SMTP2GO',
        buildRequest: (apiKey, from, to, subject, body) => ({
            url: 'https://api.smtp2go.com/v3/email/send',
            options: {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    api_key: apiKey,
                    sender: from,
                    to: [to],
                    subject: subject,
                    text_body: body
                })
            }
        }),
        isSuccess: (status) => status >= 200 && status < 300
    },
    resend: {
        name: 'Resend',
        buildRequest: (apiKey, from, to, subject, body) => ({
            url: 'https://api.resend.com/emails',
            options: {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${apiKey}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    from: from,
                    to: [to],
                    subject: subject,
                    text: body
                })
            }
        }),
        isSuccess: (status) => status >= 200 && status < 300
    }
};


// ===== REQUEST LOCK (prevents double-fire) =====
const activeLocks = new Set();

// ===== MESSAGE HANDLER =====
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'analyzeWebsite') {
        if (activeLocks.has('analyze')) {
            sendResponse({ success: false, error: 'Analysis already in progress.' });
            return true;
        }
        activeLocks.add('analyze');
        handleAnalyzeWebsite(request)
            .then(r => sendResponse(r))
            .catch(e => sendResponse({ success: false, error: e.message }))
            .finally(() => activeLocks.delete('analyze'));
        return true;
    }

    if (request.action === 'generateSalesContent') {
        const lockKey = `sales_${request.contentType}`;
        if (activeLocks.has(lockKey)) {
            sendResponse({ success: false, error: 'Generation already in progress.' });
            return true;
        }
        activeLocks.add(lockKey);
        handleSalesContent(request)
            .then(r => sendResponse(r))
            .catch(e => sendResponse({ success: false, error: e.message }))
            .finally(() => activeLocks.delete(lockKey));
        return true;
    }

    if (request.action === 'getProviders') {
        const list = {};
        for (const [k, v] of Object.entries(PROVIDERS)) {
            list[k] = { name: v.name, defaultModel: v.defaultModel };
        }
        sendResponse({ success: true, data: list });
        return true;
    }

    if (request.action === 'getRateLimitStatus') {
        rateLimiter.load().then(() => {
            sendResponse({ success: true, data: rateLimiter.status() });
        });
        return true;
    }

    if (request.action === 'getAnalysisHistory') {
        chrome.storage.local.get(['analysisHistory']).then(s => {
            sendResponse({ success: true, data: s.analysisHistory || [] });
        });
        return true;
    }

    if (request.action === 'clearAnalysisHistory') {
        chrome.storage.local.set({ analysisHistory: [] }).then(() => {
            sendResponse({ success: true });
        });
        return true;
    }

    if (request.action === 'sendEmail') {
        if (activeLocks.has('sendEmail')) {
            sendResponse({ success: false, error: 'Already sending an email.' });
            return true;
        }
        activeLocks.add('sendEmail');
        handleSendEmail(request)
            .then(r => sendResponse(r))
            .catch(e => sendResponse({ success: false, error: e.message }))
            .finally(() => activeLocks.delete('sendEmail'));
        return true;
    }
});


// ===== CORE FLOWS =====
async function handleAnalyzeWebsite(request) {
    const settings = await chrome.storage.local.get([
        'provider', 'apiKey', 'model', 'baseUrl',
        'temperature', 'maxTokens', 'timeout', 'maxRequestsPerMin', 'saveHistory'
    ]);

    validateApiKey(settings.apiKey);
    if (settings.baseUrl) validateBaseUrl(settings.baseUrl);

    // Rate limit check
    await rateLimiter.load();
    const rlCheck = rateLimiter.check();
    if (!rlCheck.allowed) {
        throw new Error(`Rate limit exceeded. Try again in ${rlCheck.retryAfterSec}s. (${rateLimiter.maxRequests} requests/min)`);
    }

    const provider = PROVIDERS[settings.provider || 'openai'];
    if (!provider) throw new Error(`Unknown provider: ${settings.provider}`);

    const websiteData = request.websiteData;
    if (!websiteData?.url) throw new Error('No website data received.');

    const userPrompt = buildWebsitePrompt(websiteData);
    const aiSettings = {
        temperature: parseFloat(settings.temperature) || 0.3,
        maxTokens: parseInt(settings.maxTokens) || 6000,
        timeout: parseInt(settings.timeout) || 60
    };

    rateLimiter.consume();

    const profile = await callAIProvider(provider, settings, SYSTEM_PROMPT, userPrompt, aiSettings);

    // Save to history if enabled
    if (settings.saveHistory !== 'false') {
        try {
            const histData = await chrome.storage.local.get(['analysisHistory']);
            const history = histData.analysisHistory || [];
            history.unshift({
                companyName: profile.companyName || 'Unknown',
                website: profile.website || websiteData.url,
                industry: profile.industry || 'N/A',
                chiScore: profile.scores?.companyHealth?.score || 0,
                analyzedAt: new Date().toISOString(),
                profile: profile
            });
            // Keep max 20 entries
            await chrome.storage.local.set({ analysisHistory: history.slice(0, 20) });
        } catch { /* history save is non-critical */ }
    }

    return { success: true, data: profile };
}


async function handleSalesContent(request) {
    const settings = await chrome.storage.local.get([
        'provider', 'apiKey', 'model', 'baseUrl',
        'temperature', 'maxTokens', 'timeout', 'maxRequestsPerMin'
    ]);

    validateApiKey(settings.apiKey);
    if (settings.baseUrl) validateBaseUrl(settings.baseUrl);

    // Rate limit check
    await rateLimiter.load();
    const rlCheck = rateLimiter.check();
    if (!rlCheck.allowed) {
        throw new Error(`Rate limit exceeded. Try again in ${rlCheck.retryAfterSec}s.`);
    }

    const provider = PROVIDERS[settings.provider || 'openai'];
    if (!provider) throw new Error(`Unknown provider: ${settings.provider}`);

    const { contentType, profile, senderProfile, targetContact } = request;
    const promptFn = SALES_PROMPTS[contentType];
    if (!promptFn) throw new Error(`Unknown content type: ${contentType}`);

    const systemPrompt = 'You are an elite B2B sales copywriter. Write like a human, not an AI. Be direct, casual, and professional. Do NOT use buzzwords. Do NOT use em-dashes (—); use simple hyphens (-) instead. Keep sentences short.';
    const userPrompt = promptFn(profile, senderProfile, targetContact);

    const aiSettings = {
        temperature: parseFloat(settings.temperature) || 0.3,
        maxTokens: parseInt(settings.maxTokens) || 6000,
        timeout: parseInt(settings.timeout) || 60
    };

    rateLimiter.consume();

    const content = await callAIProviderRaw(provider, settings, systemPrompt, userPrompt, aiSettings);
    return { success: true, data: content };
}


// ===== EMAIL RATE LIMITER (10 per hour) =====
const emailRateLimiter = {
    timestamps: [],
    maxPerHour: 10,
    check() {
        const now = Date.now();
        this.timestamps = this.timestamps.filter(t => now - t < 3600000);
        return this.timestamps.length < this.maxPerHour;
    },
    consume() {
        this.timestamps.push(Date.now());
    },
    remaining() {
        const now = Date.now();
        this.timestamps = this.timestamps.filter(t => now - t < 3600000);
        return Math.max(0, this.maxPerHour - this.timestamps.length);
    }
};

// ===== SECURITY: Input sanitizers =====
function sanitizeSubject(subj) {
    // Strip CR, LF, null bytes to prevent header injection
    return String(subj).replace(/[\r\n\0]/g, ' ').trim().substring(0, 500);
}

function sanitizeBody(bodyText) {
    // Strip HTML tags to prevent XSS if provider renders HTML
    return String(bodyText).replace(/<[^>]*>/g, '').substring(0, 50000);
}

function sanitizeErrorMessage(msg) {
    // Remove anything that looks like an API key from error messages
    return String(msg)
        .replace(/(?:key|token|bearer|apikey|api-key)[=:\s]+[a-zA-Z0-9._\-]{10,}/gi, '[REDACTED]')
        .replace(/SG\.[a-zA-Z0-9._\-]+/g, '[REDACTED]')
        .replace(/re_[a-zA-Z0-9]+/g, '[REDACTED]')
        .substring(0, 300);
}

async function handleSendEmail(request) {
    const { to } = request;
    let { subject, body } = request;

    // Validate inputs
    if (!to || typeof to !== 'string' || !/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(to) || to.length > 254) {
        throw new Error('Invalid recipient email address.');
    }
    if (!subject || typeof subject !== 'string') {
        throw new Error('Missing or invalid email subject.');
    }
    if (!body || typeof body !== 'string') {
        throw new Error('Missing or invalid email body.');
    }

    // Sanitize inputs
    subject = sanitizeSubject(subject);
    body = sanitizeBody(body);
    if (!subject) throw new Error('Email subject is empty after sanitization.');
    if (!body) throw new Error('Email body is empty after sanitization.');

    // Rate limit
    if (!emailRateLimiter.check()) {
        throw new Error(`Email rate limit reached (${emailRateLimiter.maxPerHour}/hour). Try again later.`);
    }

    // Load email service settings
    const settings = await chrome.storage.local.get([
        'emailProvider', 'emailApiKey', 'emailDomain', 'emailEndpoint', 'emailRegion',
        'profileEmail', 'profileName'
    ]);

    const emailProvider = settings.emailProvider;
    if (!emailProvider || emailProvider === 'none') {
        throw new Error('No email service configured. Go to Settings → Email Service.');
    }

    const provider = EMAIL_PROVIDERS[emailProvider];
    if (!provider) throw new Error(`Unknown email provider: ${emailProvider}`);

    const emailApiKey = settings.emailApiKey;
    if (!emailApiKey || emailApiKey.length < 5) {
        throw new Error('Email API key not configured or too short.');
    }

    // Validate from email
    const fromEmail = settings.profileEmail;
    if (!fromEmail || !/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(fromEmail)) {
        throw new Error('Invalid sender email. Set a valid email in Your Profile (Settings).');
    }

    // Build the "from" as "Name <email>" if name exists
    const fromName = (settings.profileName || '').replace(/[<>"]/g, '').trim();
    const from = fromName ? `${fromName} <${fromEmail}>` : fromEmail;

    // Provider-specific validation
    if (emailProvider === 'mailgun') {
        if (!settings.emailDomain) throw new Error('Mailgun domain is required.');
        // Prevent domain injection — only allow valid domain chars
        if (!/^[a-zA-Z0-9][a-zA-Z0-9.-]{1,253}[a-zA-Z0-9]$/.test(settings.emailDomain)) {
            throw new Error('Invalid Mailgun domain. Use alphanumeric characters, dots, and hyphens only.');
        }
    }
    if (emailProvider === 'ses') {
        const region = settings.emailRegion || 'us-east-1';
        // Validate SES region format
        if (!/^[a-z]{2}-[a-z]+-\d{1,2}$/.test(region)) {
            throw new Error('Invalid AWS region format (e.g. us-east-1).');
        }
    }
    if (emailProvider === 'custom') {
        if (!settings.emailEndpoint) throw new Error('Custom endpoint URL is required.');
        try {
            const parsed = new URL(settings.emailEndpoint);
            if (parsed.protocol !== 'https:') throw new Error('Custom endpoint must use HTTPS.');
        } catch (e) {
            if (e.message.includes('HTTPS')) throw e;
            throw new Error('Invalid custom endpoint URL.');
        }
    }

    // Build and send request
    const { url, options } = provider.buildRequest(
        emailApiKey, from, to, subject, body,
        settings.emailDomain, settings.emailEndpoint, settings.emailRegion
    );

    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 30000);

    try {
        const response = await fetch(url, { ...options, signal: controller.signal });
        clearTimeout(timer);

        if (!provider.isSuccess(response.status)) {
            let errMsg = `Email service returned HTTP ${response.status}`;
            try {
                const errBody = await response.text();
                errMsg += `: ${sanitizeErrorMessage(errBody)}`;
            } catch { /* ignore */ }
            throw new Error(errMsg);
        }

        emailRateLimiter.consume();
        return { success: true, data: `Email sent successfully! (${emailRateLimiter.remaining()} sends remaining this hour)` };
    } catch (e) {
        clearTimeout(timer);
        if (e.name === 'AbortError') throw new Error('Email send timed out (30s).');
        throw new Error(sanitizeErrorMessage(e.message));
    }
}


async function callAIProvider(provider, settings, systemPrompt, userPrompt, aiSettings) {
    const content = await callAIProviderRaw(provider, settings, systemPrompt, userPrompt, aiSettings);

    try {
        let jsonStr = content;
        const jsonMatch = content.match(/```(?:json)?\s*([\s\S]*?)```/);
        if (jsonMatch) jsonStr = jsonMatch[1];
        return JSON.parse(jsonStr.trim());
    } catch (e) {
        throw new Error('Failed to parse AI response as JSON. Try gpt-4o or claude-sonnet-4-20250514.');
    }
}


async function callAIProviderRaw(provider, settings, systemPrompt, userPrompt, aiSettings = {}) {
    const model = settings.model || provider.defaultModel;
    const baseUrl = settings.baseUrl || provider.baseUrl;

    const headers = provider.buildHeaders(settings.apiKey);
    const body = provider.buildBody(model, systemPrompt, userPrompt, aiSettings);

    let endpoint;
    if (provider.getEndpoint) {
        endpoint = provider.getEndpoint(baseUrl, model);
    } else if (settings.provider === 'anthropic') {
        endpoint = `${baseUrl}/messages`;
    } else {
        endpoint = `${baseUrl}/chat/completions`;
    }

    // Configurable timeout (default 60s, range 15-120s)
    const timeoutMs = Math.max(15000, Math.min(120000, (aiSettings.timeout || 60) * 1000));
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), timeoutMs);

    let response;
    try {
        response = await fetch(endpoint, {
            method: 'POST',
            headers,
            body: JSON.stringify(body),
            signal: controller.signal
        });
    } catch (e) {
        clearTimeout(timeoutId);
        if (e.name === 'AbortError') throw new Error(`Request timed out after ${aiSettings.timeout || 60}s. Try a smaller page or faster model.`);
        throw e;
    }
    clearTimeout(timeoutId);

    if (!response.ok) {
        const errorBody = await response.text();
        let errorMsg;
        try {
            const ej = JSON.parse(errorBody);
            errorMsg = ej.error?.message || ej.message || `HTTP ${response.status}`;
        } catch { errorMsg = `HTTP ${response.status}: ${errorBody.substring(0, 100)}`; }
        throw new Error(`API Error: ${errorMsg}`);
    }

    // Response size guard — prevent memory bombs
    const responseText = await response.text();
    if (responseText.length > MAX_RESPONSE_BYTES) {
        throw new Error(`Response too large (${Math.round(responseText.length / 1024)}KB). Maximum is ${MAX_RESPONSE_BYTES / 1024}KB.`);
    }

    const json = JSON.parse(responseText);
    const content = provider.parseResponse(json);
    if (!content) throw new Error('Empty response from AI. Try a different model.');
    return content;
}
