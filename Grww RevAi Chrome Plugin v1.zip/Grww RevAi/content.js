/* global chrome */

// --- 1. WEBSITE EXTRACTION FOR AI ANALYSIS ---
function extractWebsite() {
    const data = {
        title: document.title,
        url: window.location.href,
        domain: window.location.hostname,
        metaDescription: document.querySelector('meta[name="description"]')?.content || '',
        metaKeywords: document.querySelector('meta[name="keywords"]')?.content || '',
        siteName: document.querySelector('meta[property="og:site_name"]')?.content || window.location.hostname,
        headings: [],
        links: [],
        companySignals: {},
        bodyText: document.body.innerText.substring(0, 50000).replace(/\s+/g, ' ').trim() // Limit & clean
    };

    // Headings (H1-H3)
    document.querySelectorAll('h1, h2, h3').forEach(h => {
        const text = h.innerText.trim();
        if (text) {
            data.headings.push({ level: h.tagName, text: text });
        }
    });

    // Links (Priority: Nav/Header)
    const seenLinks = new Set();
    document.querySelectorAll('nav a, header a, footer a').forEach(a => {
        const text = a.innerText.trim();
        const href = a.href;
        if (text && href && !href.startsWith('javascript') && !seenLinks.has(href)) {
            // Filter short/icon links unless specific
            if (text.length > 2) {
                data.links.push({ text: text, href: href });
                seenLinks.add(href);
            }
        }
    });
    // Limit links to top 30 to save tokens
    data.links = data.links.slice(0, 30);

    // Signals (Heuristic check)
    const fullText = document.body.innerText.toLowerCase();
    data.companySignals = {
        hasAboutPage: fullText.includes('about us') || !!document.querySelector('a[href*="about"]'),
        hasPricingPage: fullText.includes('pricing') || !!document.querySelector('a[href*="pricing"]'),
        hasCareersPage: fullText.includes('careers') || fullText.includes('jobs') || !!document.querySelector('a[href*="career"]'),
        hasBlog: fullText.includes('blog') || !!document.querySelector('a[href*="blog"]'),
        hasProducts: fullText.includes('products') || !!document.querySelector('a[href*="product"]'),
        hasServices: fullText.includes('services') || !!document.querySelector('a[href*="service"]'),
        hasTestimonials: fullText.includes('testimonial') || fullText.includes('success stor') || !!document.querySelector('.testimonial'),
        hasTeamPage: fullText.includes('our team') || !!document.querySelector('a[href*="team"]')
    };

    return data;
}

// --- 2. DETAILS EXTRACTION FOR WHATSAPP/SALES ---
function extractPageDetails() {
    const details = {
        title: document.title,
        url: window.location.href,
        phones: []
    };

    // 1. Look for tel: links
    document.querySelectorAll('a[href^="tel:"]').forEach(a => {
        details.phones.push(a.href.replace('tel:', ''));
    });

    // 2. Regex scan on visible text (simple pattern)
    // Matches international formats broadly: +1-555-555-5555, (555) 555-5555
    const phoneRegex = /(?:\+?\d{1,3}[ -]?)?\(?\d{3}\)?[ -]?\d{3}[ -]?\d{4}/g;
    const text = document.body.innerText;
    const matches = text.match(phoneRegex);
    if (matches) {
        details.phones.push(...matches);
    }

    // Deduplicate and clean
    details.phones = [...new Set(details.phones.map(p => p.trim()))];

    return details;
}

// MESSAGING
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'extractWebsite') {
        const data = extractWebsite();
        sendResponse({ success: true, data: data });
    }
    else if (request.action === 'extractDetails') {
        sendResponse(extractPageDetails());
    }
    return true; // Keep channel open
});
