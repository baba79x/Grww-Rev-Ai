/**
 * Dashboard Controller — Full-Page Intelligence Report
 * Loads profile from chrome.storage, renders all sections, handles exports.
 * v2.3.0
 */
(function () {
    'use strict';

    const isExtCtx = typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.id;

    // ===== HELPERS =====
    function esc(str) {
        if (!str) return '';
        const d = document.createElement('div');
        d.textContent = String(str);
        return d.innerHTML;
    }

    function isValidEmail(email) {
        if (!email || typeof email !== 'string') return false;
        return /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(email) && email.length <= 254;
    }

    function clamp(v) { const n = Number(v); return isNaN(n) ? 0 : Math.max(0, Math.min(100, Math.round(n))); }
    function colorClass(s) { return s >= 75 ? 'c-green' : s >= 40 ? 'c-amber' : 'c-red'; }
    function gaugeClass(s) { return s >= 75 ? 'g-green' : s >= 40 ? 'g-amber' : 'g-red'; }

    const $ = id => document.getElementById(id);
    let profile = null;

    // ===== INIT =====
    async function init() {
        try {
            if (isExtCtx) {
                const data = await chrome.storage.local.get(['latestDashboardProfile', 'profileName', 'profileRole', 'profileSignature', 'profileCompany']);
                profile = data.latestDashboardProfile;
                window.senderProfile = {
                    name: data.profileName || '',
                    role: data.profileRole || '',
                    company: data.profileCompany || '',
                    signature: data.profileSignature || ''
                };
            }

            if (!profile) {
                $('loadingState').innerHTML = '<p style="color:var(--text-2);">No report data found. Run an analysis from the extension popup first.</p>';
                return;
            }

            render(profile);
            populateSalesTargets(); // New helper
            $('loadingState').classList.add('hidden');
            $('dashboardMain').style.display = 'block';
        } catch (e) {
            $('loadingState').innerHTML = `<p style="color:var(--red);">Error: ${esc(e.message)}</p>`;
        }

        // Top bar buttons
        $('btnExportPdf').addEventListener('click', exportPDF);
        $('btnExportJson').addEventListener('click', exportJSON);
        $('btnShare').addEventListener('click', shareSummary);
        $('btnRescan').addEventListener('click', () => {
            if (isExtCtx) {
                // Send message to background to notify popup, or just close
                window.close();
            }
        });

        // Sales assist
        document.querySelectorAll('.sa-btn').forEach(btn => {
            btn.addEventListener('click', () => generateSalesContent(btn.dataset.type));
        });
        $('btnCloseSales').addEventListener('click', () => $('salesModal').classList.remove('open'));
        $('btnCopySales').addEventListener('click', copySalesContent);
        $('btnOpenWhatsApp').addEventListener('click', openWhatsAppWithContent);

        // Send email
        const sendBtn = $('btnSendEmail');
        if (sendBtn) sendBtn.addEventListener('click', handleDashboardSendEmail);
    }

    // ===== RENDER ALL =====
    function render(p) {
        // Company bar
        $('companyName').textContent = p.companyName || 'Unknown Company';
        $('companyDomain').textContent = p.website || '—';
        $('scanDate').textContent = `Scanned: ${new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}`;

        // CHI hero
        const chi = clamp(p.scores?.companyHealth?.score);
        $('chiHeroValue').textContent = chi;
        $('chiHeroValue').className = `chi-hero-value ${colorClass(chi)}`;

        // Score cards
        renderScoreCards(p.scores);

        // Revenue
        renderRevenue(p.revenueIntelligence);

        // Alerts
        renderAlerts(p.alerts);

        // Opportunities
        renderOpportunities(p.opportunities);

        // Competitors
        renderCompetitors(p.competitors);

        // Market
        renderMarket(p.marketAnalysis);

        // Action plan
        renderActionPlan(p.actionPlan);

        // Key contacts
        renderContacts(p.keyContacts || p.keyPeople);

        // Trigger animations
        setTimeout(() => {
            const cards = document.querySelectorAll('.sc, .card');
            cards.forEach((c) => {
                c.classList.add('animate-in');
            });
        }, 50);
    }

    // ===== SCORE CARDS =====
    function renderScoreCards(scores) {
        if (!scores) return;
        const order = [
            { key: 'salesOpportunity', icon: '📈' },
            { key: 'conversionEfficiency', icon: '🎯' },
            { key: 'seoStrength', icon: '🔍' },
            { key: 'technicalQuality', icon: '⚡' },
        ];

        const grid = $('scoreCards');
        grid.innerHTML = '';

        order.forEach(({ key }) => {
            const s = scores[key];
            if (!s) return;
            const score = clamp(s.score);
            const circumference = 2 * Math.PI * 25; // r=25

            const card = document.createElement('div');
            card.className = 'sc';
            card.innerHTML = `
                <div class="sc-info">
                    <span class="sc-score ${colorClass(score)}">${score}</span>
                    <span class="sc-label">${esc(s.label)}</span>
                    <span class="sc-detail">"${esc(s.details?.substring(0, 60))}…"</span>
                </div>
                <div class="sc-gauge">
                    <svg width="64" height="64" viewBox="0 0 64 64">
                        <circle class="sc-gauge-bg" cx="32" cy="32" r="25" />
                        <circle class="sc-gauge-fill ${gaugeClass(score)}" cx="32" cy="32" r="25"
                            stroke-dasharray="${circumference}"
                            stroke-dashoffset="${circumference}" />
                    </svg>
                </div>
            `;
            grid.appendChild(card);

            // Animate gauge
            setTimeout(() => {
                const fill = card.querySelector('.sc-gauge-fill');
                fill.style.strokeDashoffset = circumference - (score / 100) * circumference;
            }, 100);
        });
    }

    // ===== REVENUE =====
    function renderRevenue(rev) {
        if (!rev) { $('revenueCard').style.display = 'none'; return; }

        const sev = (rev.severity || 'medium').toLowerCase();
        const badge = $('revSeverity');
        badge.textContent = rev.severity || 'Medium';
        badge.className = `severity-badge sev-${sev}`;
        $('revAmount').textContent = rev.estimatedLeakRange || '—';

        const container = $('revCauses');
        container.innerHTML = '';

        (rev.causes || []).forEach((c, i) => {
            const colors = ['var(--red)', 'var(--amber)', 'var(--accent)', 'var(--green)', 'var(--blue)'];
            const priorities = ['high', 'high', 'medium', 'medium', 'low'];
            const dot = colors[i % colors.length];
            const pri = priorities[Math.min(i, priorities.length - 1)];

            const card = document.createElement('div');
            card.className = 'rev-cause';
            card.innerHTML = `
                <div class="rev-cause-title"><span class="rev-cause-dot" style="background:${dot}"></span>${esc(c.cause)}</div>
                <div class="rev-cause-impact">Impact: ${esc(c.impact)}</div>
                <div class="rev-cause-fix">Fix: ${esc(c.fix)}</div>
                <span class="rev-cause-priority priority-${pri}">${pri === 'high' ? 'High Priority' : pri === 'medium' ? 'Medium Priority' : 'Low Priority'}</span>
            `;
            container.appendChild(card);
        });
    }

    // ===== ALERTS =====
    function renderAlerts(alerts) {
        if (!alerts?.length) { $('alertsCard').style.display = 'none'; return; }

        const iconMap = {
            critical: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>`,
            improvement: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>`,
            optimized: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 11-5.93-9.14"/><polyline points="22,4 12,14.01 9,11.01"/></svg>`,
        };

        const list = $('alertsList');
        list.innerHTML = '';
        const validSev = new Set(['critical', 'improvement', 'optimized']);

        setupPaginatedList(alerts, list, 4, (a) => {
            const sev = validSev.has(a.severity) ? a.severity : 'improvement';
            const row = document.createElement('div');
            row.className = 'alert-row';
            row.innerHTML = `
                <div class="alert-icon ${sev}">${iconMap[sev] || iconMap.improvement}</div>
                <div class="alert-body">
                    <div class="alert-title">${esc(a.title)}</div>
                    <div class="alert-detail">${esc(a.detail)}</div>
                </div>
            `;
            return row;
        }, 'alertsPrev', 'alertsNext');
    }

    // ===== OPPORTUNITIES =====
    function renderOpportunities(opps) {
        if (!opps?.length) { $('oppsCard').style.display = 'none'; return; }

        const carousel = $('oppsCarousel');
        carousel.innerHTML = '';

        const oppIcons = [
            `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/><path d="M11 8v6M8 11h6"/></svg>`,
            `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--green)" stroke-width="2"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>`,
            `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--amber)" stroke-width="2"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6"/></svg>`,
            `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--blue)" stroke-width="2"><rect x="2" y="3" width="20" height="14" rx="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg>`,
        ];

        opps.sort((a, b) => (a.priority || 99) - (b.priority || 99)).forEach((o, i) => {
            const card = document.createElement('div');
            card.className = 'opp-card';
            card.innerHTML = `
                <div>
                    <div class="opp-card-icon">${oppIcons[i % oppIcons.length]}</div>
                    <div class="opp-card-title">${esc(o.service)}</div>
                    <div class="opp-card-budget">${esc(o.estimatedBudget || '—')}</div>
                </div>
                <button class="opp-card-btn" data-opp="${esc(o.service)}">Generate Proposal</button>
            `;
            card.querySelector('.opp-card-btn').addEventListener('click', () => {
                generateSalesContent('proposalOutline');
            });
            carousel.appendChild(card);
        });

        setupCarousel(carousel, 'oppsPrev', 'oppsNext', 234);
    }

    // ===== COMPETITORS =====
    function renderCompetitors(comps) {
        if (!comps?.length) { $('compCard').style.display = 'none'; return; }

        const carousel = $('compCarousel');
        carousel.innerHTML = '';

        comps.forEach(c => {
            const initial = (c.name || '?')[0].toUpperCase();
            const card = document.createElement('div');
            card.className = 'comp-card';
            card.innerHTML = `
                <div class="comp-card-head">
                    <div class="comp-card-icon">${initial}</div>
                    <div>
                        <div class="comp-card-name">${esc(c.name)}</div>
                        <div class="comp-card-pos">${esc(c.marketPosition || c.description || '—')}</div>
                    </div>
                </div>
            `;
            carousel.appendChild(card);
        });

        setupCarousel(carousel, 'compPrev', 'compNext', 204);
    }

    // ===== MARKET ANALYSIS =====
    function renderMarket(ma) {
        if (!ma) { $('marketCard').style.display = 'none'; return; }

        const grid = $('marketGrid');
        grid.innerHTML = '';

        // Stat boxes
        if (ma.marketSize) grid.innerHTML += `<div class="market-stat"><div class="market-stat-label">Market Size</div><div class="market-stat-value">${esc(ma.marketSize)}</div></div>`;
        if (ma.growthRate) grid.innerHTML += `<div class="market-stat"><div class="market-stat-label">Growth Rate</div><div class="market-stat-value">${esc(ma.growthRate)}</div></div>`;

        // List sections
        const sections = [
            { key: 'opportunities', label: 'Opportunities' },
            { key: 'threats', label: 'Threats' },
            { key: 'trends', label: 'Trends' },
        ];

        sections.forEach(s => {
            const items = ma[s.key];
            if (!items?.length) return;
            const div = document.createElement('div');
            div.className = 'market-list';
            div.innerHTML = `<div class="market-list-title">${s.label}</div><ul>${items.map(i => `<li>${esc(i)}</li>`).join('')}</ul>`;
            grid.appendChild(div);
        });
    }

    // ===== ACTION PLAN =====
    function renderActionPlan(plan) {
        if (!plan?.length) { $('actionCard').style.display = 'none'; return; }

        const list = $('actionList');
        list.innerHTML = '';

        setupPaginatedList(plan, list, 10, (a, index) => { // Increased logic to show all or pagination
            const row = document.createElement('div');
            row.className = 'action-row';

            // Handle both old and new schema just in case
            const title = a.step || a.action || 'Unknown Action';
            const desc = a.description || '';
            const why = a.justification ? `<strong>Why:</strong> ${a.justification}` : '';
            const how = a.implementation ? `<strong>How:</strong> ${a.implementation}` : '';
            const priority = (a.priority || 'Medium').toLowerCase();

            row.innerHTML = `
                <div class="action-num">${index + 1}</div>
                <div class="action-body">
                    <div class="action-header">
                        <span class="action-title">${esc(title)}</span>
                        <span class="action-badge priority-${priority}">${esc(a.priority || 'Medium')}</span>
                    </div>
                    ${desc ? `<div class="action-desc">${esc(desc)}</div>` : ''}
                    <div class="action-details">
                        ${why ? `<div class="detail-item">${why}</div>` : ''}
                        ${how ? `<div class="detail-item">${how}</div>` : ''}
                    </div>
                </div>
                <div class="action-meta-col">
                    <div class="meta-item">Impact: ${esc(a.impact || 'Medium')}</div>
                    <div class="meta-item">Time: ${esc(a.timeline || a.timeframe || 'TBD')}</div>
                </div>
            `;
            return row;
        }, 'actionPrev', 'actionNext');
    }

    // ===== KEY CONTACTS =====
    function renderContacts(contacts) {
        if (!contacts?.length) { $('contactsCard').style.display = 'none'; return; }

        const list = $('contactsList');
        list.innerHTML = '';

        contacts.forEach(c => {
            const name = c.name || 'Unknown';
            const initial = name[0].toUpperCase();
            const role = c.title || c.role || '—';
            const email = c.email;

            const row = document.createElement('div');
            row.className = 'contact-row';

            let actions = '';

            // Email
            if (email && isValidEmail(email)) {
                actions += `<a href="mailto:${esc(email)}" class="ca-btn" title="Send email">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="M22 7l-10 7L2 7"/></svg>
                    Email
                </a>`;
            }

            // WhatsApp
            const waMsg = buildWhatsAppMessage(name, role);
            actions += `<a href="https://wa.me/?text=${encodeURIComponent(waMsg)}" target="_blank" class="ca-btn ca-btn-wa" title="WhatsApp">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="var(--wa-green)"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
                WhatsApp
            </a>`;

            // Connect (LinkedIn search)
            actions += `<a href="https://www.linkedin.com/search/results/all/?keywords=${encodeURIComponent(name + ' ' + (profile?.companyName || ''))}" target="_blank" class="ca-btn" title="Find on LinkedIn">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M16 8a6 6 0 016 6v7h-4v-7a2 2 0 00-4 0v7h-4v-7a6 6 0 016-6z"/><rect x="2" y="9" width="4" height="12"/><circle cx="4" cy="4" r="2"/></svg>
                Connect
            </a>`;

            row.innerHTML = `
                <div class="contact-left">
                    <div class="contact-avatar">${esc(initial)}</div>
                    <div>
                        <div class="contact-name">${esc(name)}</div>
                        <div class="contact-role">${esc(role)}</div>
                    </div>
                </div>
                <div class="contact-actions">${actions}</div>
            `;
            list.appendChild(row);
        });
    }

    // ===== WHATSAPP MESSAGE BUILDER =====
    function buildWhatsAppMessage(contactName, role) {
        const company = profile?.companyName || 'your company';
        const chi = profile?.scores?.companyHealth?.score || '—';
        const topIssue = profile?.revenueIntelligence?.causes?.[0]?.cause || 'growth optimization';
        const leakRange = profile?.revenueIntelligence?.estimatedLeakRange || 'significant revenue';

        return `Hi ${contactName}! 👋\n\nI'm reaching out from Grww. We recently analyzed ${company}'s website and found some interesting insights:\n\n📊 Health Score: ${chi}/100\n⚠️ Key Finding: ${topIssue}\n💰 Estimated Impact: ${leakRange}/year\n\nWe've helped similar companies fix these exact issues. Would you be open to a quick 10-min call to walk through the findings?\n\nBest regards`;
    }

    // ===== SALES TARGET POPULATION =====
    function populateSalesTargets() {
        const select = $('salesTargetSelect');
        if (!select) return;
        select.innerHTML = '<option value="">Select Target Contact...</option>';

        if (profile?.keyPeople?.length) {
            profile.keyPeople.forEach(p => {
                if (p.name) {
                    const opt = document.createElement('option');
                    opt.value = p.email || '';
                    opt.textContent = `${p.name} ${p.role ? '(' + p.role + ')' : ''}`;
                    select.appendChild(opt);
                }
            });
            // Auto-select first if available
            if (profile.keyPeople[0]?.name) select.selectedIndex = 1;
        }

        // Add change listener to pre-fill email input if cold email is active
        select.addEventListener('change', () => {
            const val = select.value;
            if (val && currentSalesType === 'coldEmail') {
                const inp = $('dashRecipientEmail');
                if (inp) inp.value = val;
            }
        });
    }

    // ===== SALES CONTENT GENERATION =====
    let currentSalesType = null;

    async function generateSalesContent(type) {
        if (!profile) return;
        currentSalesType = type;

        const labels = {
            coldEmail: 'Cold Email',
            linkedinDM: 'LinkedIn DM',
            whatsappDM: 'WhatsApp Message',
            auditPitch: 'Audit Pitch',
            proposalOutline: 'Proposal Outline'
        };

        $('salesModalTitle').textContent = labels[type] || 'Generated Content';
        $('salesModalContent').textContent = 'Generating…';
        $('salesModal').classList.add('open');

        // Show WhatsApp send button only for WhatsApp type
        $('btnOpenWhatsApp').style.display = type === 'whatsappDM' ? 'flex' : 'none';

        // Show send email UI for cold email
        const isColdEmail = type === 'coldEmail';
        const sendBtn = $('btnSendEmail');
        const sendBar = $('dashSendEmailBar');
        const sendStatus = $('dashSendEmailStatus');
        if (sendBtn) sendBtn.style.display = isColdEmail ? 'flex' : 'none';
        if (sendBar) sendBar.style.display = isColdEmail ? '' : 'none';
        if (sendStatus) { sendStatus.textContent = ''; sendStatus.className = 'send-email-status'; }

        // Get selected target
        const select = $('salesTargetSelect');
        const targetEmail = select.value;
        const targetName = select.options[select.selectedIndex]?.text?.split(' (')[0] || '';

        // Auto-fill email if selected
        if (isColdEmail && targetEmail) {
            const inp = $('dashRecipientEmail');
            if (inp) inp.value = targetEmail;
        }

        document.querySelectorAll('.sa-btn').forEach(b => b.disabled = true);

        try {
            if (!isExtCtx) {
                $('salesModalContent').textContent = 'Sales content generation requires the Chrome extension context.';
            } else {
                const result = await chrome.runtime.sendMessage({
                    action: 'generateSalesContent',
                    contentType: type,
                    profile: profile,
                    senderProfile: window.senderProfile || {}, // Pass sender profile
                    targetContact: { name: targetName, email: targetEmail } // Pass target info
                });
                if (!result?.success) throw new Error(result?.error || 'Generation failed.');
                // Format content: Sanitize FIRST, then apply markdown
                let safeText = esc(result.data); // Prevent XSS
                let formatted = safeText
                    .replace(/^### (.*$)/gim, '<h3>$1</h3>')
                    .replace(/^## (.*$)/gim, '<h4>$1</h4>')
                    .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
                    .replace(/\*(.*?)\*/g, '<em>$1</em>')
                    .replace(/\n/g, '<br>');

                $('salesModalContent').innerHTML = formatted;
            }
        } catch (e) {
            $('salesModalContent').textContent = `Error: ${e.message}`;
        }

        document.querySelectorAll('.sa-btn').forEach(b => b.disabled = false);
    }

    function copySalesContent() {
        const text = $('salesModalContent').textContent;
        navigator.clipboard.writeText(text);
        const btn = $('btnCopySales');
        const orig = btn.innerHTML;
        btn.innerHTML = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="var(--green)" stroke-width="2"><polyline points="20,6 9,17 4,12"/></svg> Copied!`;
        setTimeout(() => { btn.innerHTML = orig; }, 2000);
    }

    function openWhatsAppWithContent() {
        const text = $('salesModalContent').textContent;
        if (text && text !== 'Generating…') {
            window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank');
        }
    }

    async function handleDashboardSendEmail() {
        const recipientInput = $('dashRecipientEmail');
        const statusEl = $('dashSendEmailStatus');
        const sendBtn = $('btnSendEmail');
        if (!recipientInput || !statusEl || !sendBtn) return;

        const recipient = recipientInput.value.trim();
        if (!recipient || !isValidEmail(recipient)) {
            statusEl.textContent = 'Invalid email';
            statusEl.className = 'send-email-status error';
            return;
        }

        const content = $('salesModalContent').textContent;
        if (!content || content === 'Generating…') return;

        // Parse SUBJECT line
        let subject = 'Intro — ' + (profile?.companyName || 'Growth Opportunity');
        let body = content;
        const subjectMatch = content.match(/^SUBJECT:\s*(.+)/i);
        if (subjectMatch) {
            subject = subjectMatch[1].trim();
            body = content.substring(content.indexOf('\n', content.indexOf(subjectMatch[0]))).trim();
        }

        sendBtn.disabled = true;
        statusEl.textContent = 'Sending…';
        statusEl.className = 'send-email-status';

        try {
            const result = await chrome.runtime.sendMessage({
                action: 'sendEmail',
                to: recipient,
                subject: subject,
                body: body
            });
            if (result?.success) {
                statusEl.textContent = '✓ Sent!';
                statusEl.className = 'send-email-status success';
            } else {
                statusEl.textContent = result?.error || 'Failed';
                statusEl.className = 'send-email-status error';
            }
        } catch (e) {
            statusEl.textContent = e.message;
            statusEl.className = 'send-email-status error';
        }
        sendBtn.disabled = false;
    }

    // ===== CAROUSEL HELPER =====
    function setupCarousel(container, prevId, nextId, itemWidth) {
        let offset = 0;
        const items = container.children.length;
        const maxOffset = Math.max(0, (items * itemWidth) - container.parentElement.offsetWidth);

        $(prevId).addEventListener('click', () => {
            offset = Math.max(0, offset - itemWidth);
            container.style.transform = `translateX(-${offset}px)`;
        });

        $(nextId).addEventListener('click', () => {
            offset = Math.min(maxOffset, offset + itemWidth);
            container.style.transform = `translateX(-${offset}px)`;
        });
    }

    // ===== PAGINATED LIST HELPER =====
    function setupPaginatedList(items, container, pageSize, renderFn, prevId, nextId) {
        let page = 0;
        const totalPages = Math.ceil(items.length / pageSize);

        function renderPage() {
            container.innerHTML = '';
            const start = page * pageSize;
            const slice = items.slice(start, start + pageSize);
            slice.forEach(item => container.appendChild(renderFn(item)));
        }

        renderPage();

        $(prevId).addEventListener('click', () => {
            if (page > 0) { page--; renderPage(); }
        });

        $(nextId).addEventListener('click', () => {
            if (page < totalPages - 1) { page++; renderPage(); }
        });
    }

    // ===== EXPORT =====
    function exportPDF() {
        if (!profile) return;
        try {
            window.generateCompanyProfilePDF(profile);
        } catch (e) {
            alert('PDF export failed: ' + e.message);
        }
    }

    function exportJSON() {
        if (!profile) return;
        try {
            const jsonStr = JSON.stringify(profile, null, 2);
            const blob = new Blob([jsonStr], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            const safeName = (profile.companyName || 'company').replace(/[^a-zA-Z0-9]/g, '_').substring(0, 30);
            a.href = url;
            a.download = `${safeName}_Intelligence_Report.json`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        } catch (e) {
            alert('JSON export failed: ' + e.message);
        }
    }

    function shareSummary() {
        if (!profile) return;
        const chi = profile.scores?.companyHealth?.score || '—';
        const summary = `🔍 Grww RevAi Report: ${profile.companyName || 'Company'}\n📊 Health Score: ${chi}/100\n🏭 Industry: ${profile.industry || 'N/A'}\n💰 Revenue Leak: ${profile.revenueIntelligence?.estimatedLeakRange || 'N/A'}\n🌐 ${profile.website || ''}\n\nGenerated by Grww RevAi — wegrww.com`;

        navigator.clipboard.writeText(summary);

        const btn = $('btnShare');
        const orig = btn.innerHTML;
        btn.innerHTML = `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="var(--green)" stroke-width="2"><polyline points="20,6 9,17 4,12"/></svg> Copied!`;
        setTimeout(() => { btn.innerHTML = orig; }, 2000);
    }

    // ===== KICK OFF =====
    document.addEventListener('DOMContentLoaded', init);
})();
