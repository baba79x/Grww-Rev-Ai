/**
 * PDF Generator — "Million Dollar Proposal" Style
 * Generates a high-end, professional consulting report using jsPDF.
 * Design: Sleek Dark Cover + Clean White Interior Pages.
 */

(function () {
    'use strict';

    // BRAND COLORS
    const C = {
        coverBg: '#0F1115', // Dark luxury background for cover
        coverText: '#FFFFFF',
        accent: '#22C55E',  // Grww Green
        white: '#FFFFFF',
        textMain: '#111827', // Gray-900 (High contrast)
        textSec: '#4B5563',  // Gray-600
        textMuted: '#9CA3AF', // Gray-400
        border: '#E5E7EB',   // Gray-200
        bgSection: '#F9FAFB', // Gray-50

        // Score colors
        high: '#22C55E',
        med: '#F59E0B',
        low: '#EF4444'
    };

    function getScoreColor(s) {
        if (s >= 80) return C.high;
        if (s >= 50) return C.med;
        return C.low;
    }

    window.generateCompanyProfilePDF = function (profile) {
        if (!window.jspdf) {
            alert('PDF library not loaded. Please try again.');
            return;
        }

        const { jsPDF } = window.jspdf;
        const doc = new jsPDF({ unit: 'mm', format: 'a4' }); // 210 x 297 mm
        const W = 210;
        const H = 297;
        const M = 24; // More spacious margin
        const CW = W - (M * 2);
        let y = M;

        // HELPER: Add new page with footer
        function addPage(isCover = false) {
            doc.addPage();
            y = M;
            if (!isCover) addFooter();
        }

        // HELPER: Footer
        function addFooter() {
            const totalPages = doc.internal.getNumberOfPages();
            doc.setFontSize(8);
            doc.setTextColor(C.textMuted);
            doc.setFont('helvetica', 'normal');
            doc.text(`Grww Revenue Intelligence  |  ${String(profile.companyName || 'Confidential')}`, M, H - 12);
            doc.text(`Page ${String(totalPages)}`, W - M, H - 12, { align: 'right' });
        }

        // HELPER: Draw Wrapped Text
        function drawText(text, fontSize, color, fontType = 'normal', align = 'left', maxWidth = CW) {
            doc.setFontSize(fontSize);
            doc.setTextColor(color);
            doc.setFont('helvetica', fontType);
            const lines = doc.splitTextToSize(String(text || ''), maxWidth);
            const lineHeight = fontSize * 0.45; // More breathing room
            const height = lines.length * lineHeight * 1.5;

            if (y + height > H - 25) {
                addPage();
            }

            doc.text(lines, align === 'center' ? W / 2 : (align === 'right' ? W - M : M), y, { align: align });
            y += height + 4;
            return lines.length;
        }

        // HELPER: Draw Section Header (Modern)
        function drawSectionHeader(title) {
            if (y > H - 60) addPage();
            y += 10;

            // Accent pill
            doc.setFillColor(C.accent);
            doc.roundedRect(M, y - 4, 6, 24, 2, 2, 'F');

            doc.setFontSize(22);
            doc.setTextColor(C.textMain);
            doc.setFont('helvetica', 'bold');
            doc.text(String(title || '').toUpperCase(), M + 12, y + 14);

            y += 28; // Spacious gap
        }

        // HELPER: Draw Metric Card
        function drawMetricBox(x, yy, w, h, label, value, color) {
            doc.setDrawColor(C.border);
            doc.setFillColor(C.white);
            doc.roundedRect(x, yy, w, h, 3, 3, 'FD'); // Soft radius

            // Label
            doc.setFontSize(9);
            doc.textColor = C.textSec; // Fix typo in previous version if any, jsPDF uses setTextColor
            doc.setTextColor(C.textSec);
            doc.setFont('helvetica', 'bold');
            doc.text(String(label || '').toUpperCase(), x + 6, yy + 10);

            // Value
            doc.setFontSize(22); // Bigger
            doc.setTextColor(color || C.textMain);
            doc.setFont('helvetica', 'bold');
            doc.text(String(value), x + 6, yy + 28);
        }

        // ==========================================
        // PAGE 1: COVER PAGE (The "Million Dollar" Look)
        // ==========================================

        // Dark Background
        doc.setFillColor(C.coverBg);
        doc.rect(0, 0, W, H, 'F');

        // Logo / Accent
        doc.setFillColor(C.accent);
        doc.circle(W / 2, H / 2 - 40, 60, 'F'); // Abstract green globe behind
        doc.setFillColor(C.coverBg);
        doc.circle(W / 2, H / 2 - 40, 59, 'F'); // Thinner ring

        // Big Company Name
        doc.setTextColor(C.coverText);
        doc.setFontSize(44); // Larger
        doc.setFont('helvetica', 'bold');
        const titleLines = doc.splitTextToSize(String(profile.companyName || 'Company').toUpperCase(), 160);
        doc.text(titleLines, W / 2, H / 2 - 10, { align: 'center' });

        // Report Type
        doc.setFontSize(14);
        doc.setTextColor(C.accent);
        doc.setFont('helvetica', 'bold');
        doc.text('REVENUE INTELLIGENCE REPORT', W / 2, H / 2 - 35 - (titleLines.length * 12), { align: 'center' });

        // Date & Meta
        doc.setFontSize(11);
        doc.setTextColor(156, 163, 175); // gray-400
        doc.setFont('helvetica', 'normal');
        const dateStr = new Date().toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
        doc.text(`PREPARED FOR EXECUTIVE TEAM  |  ${dateStr}`, W / 2, H - 45, { align: 'center' });

        // Branding
        doc.setFontSize(16);
        doc.setTextColor(C.white);
        doc.setFont('helvetica', 'bold');
        doc.text('Grww RevAi', W / 2, H - 35, { align: 'center' });


        // ==========================================
        // PAGE 2: EXECUTIVE SUMMARY
        // ==========================================
        addPage();

        y = 35;
        drawText('Executive Summary', 32, C.textMain, 'bold');
        y += 8;
        drawText(`An AI-driven analysis of ${profile.companyName}'s revenue engine, highlighting critical leaks and growth opportunities.`, 12, C.textSec);
        y += 20;

        // --- HERO METRICS ROW ---
        const boxW = (CW - 10) / 3;
        const boxH = 40; // Taller
        const heroY = y;

        // Health Score
        const chi = profile.scores?.companyHealth?.score || 0;
        drawMetricBox(M, y, boxW, boxH, 'Company Health', `${chi}/100`, getScoreColor(chi));

        // Industry
        drawMetricBox(M + boxW + 5, y, boxW, boxH, 'Industry Sector', String(profile.industry || 'Tech').substring(0, 18), C.textMain);

        // Revenue Leak
        const leak = profile.revenueIntelligence?.estimatedLeakRange || '$0 - $0';
        drawMetricBox(M + (boxW + 5) * 2, y, boxW, boxH, 'Est. Revenue Leak', leak, C.low);

        y += boxH + 20;

        // --- CRITICAL INSIGHTS ---
        drawSectionHeader('Critical Findings');
        const causes = profile.revenueIntelligence?.causes || [];
        if (causes.length > 0) {
            causes.slice(0, 5).forEach((cause, i) => {
                const causeText = String(cause.cause || '');
                const impactText = cause.impact ? `Impact: ${cause.impact}` : '';

                // Calculate height
                doc.setFontSize(12);
                doc.setFont('helvetica', 'bold');
                const causeLines = doc.splitTextToSize(causeText, CW - 15);

                doc.setFontSize(11);
                doc.setFont('helvetica', 'normal');
                const impactLines = impactText ? doc.splitTextToSize(impactText, CW - 15) : [];

                const blockH = (causeLines.length * 6) + (impactLines.length * 5) + 8;

                // Page break check
                if (y + blockH > H - 25) addPage();

                // Bullet
                doc.setFillColor(C.textSec);
                doc.circle(M + 3, y + 4, 1.5, 'F');

                // Draw Cause
                doc.setFontSize(12);
                doc.setTextColor(C.textMain);
                doc.setFont('helvetica', 'bold');
                doc.text(causeLines, M + 10, y + 5);

                // Draw Impact
                if (impactLines.length > 0) {
                    doc.setFontSize(11);
                    doc.setTextColor(C.textSec);
                    doc.setFont('helvetica', 'normal');
                    doc.text(impactLines, M + 10, y + 5 + (causeLines.length * 6));
                }

                y += blockH + 2;
            });
        } else {
            drawText('No critical issues detected.', 12, C.textSec);
        }

        y += 15;

        // --- OPPORTUNITIES ---
        drawSectionHeader('Growth Opportunities');
        const opps = profile.opportunities || [];
        if (opps.length > 0) {
            opps.slice(0, 5).forEach((opp, i) => {
                doc.setFontSize(11);
                doc.setFont('helvetica', 'bold');
                const title = String(opp.service || '').toUpperCase();

                doc.setFontSize(10);
                doc.setFont('helvetica', 'normal');
                const desc = `${opp.reason || ''}. Est. Budget: ${opp.estimatedBudget || 'TBD'}`;
                const descLines = doc.splitTextToSize(desc, CW - 12); // Less margin inside card

                const cardH = 12 + (descLines.length * 5) + 6;

                if (y + cardH > H - 25) addPage();

                // Card bg
                doc.setFillColor(C.bgSection);
                doc.roundedRect(M, y, CW, cardH, 2, 2, 'F');

                // Title
                doc.setTextColor(C.accent);
                doc.setFontSize(11);
                doc.setFont('helvetica', 'bold');
                doc.text(title, M + 6, y + 8);

                // Desc
                doc.setTextColor(C.textMain);
                doc.setFontSize(10);
                doc.setFont('helvetica', 'normal');
                doc.text(descLines, M + 6, y + 16);

                y += cardH + 6; // More gap
            });
        } else {
            drawText('No specific opportunities identified.', 12, C.textSec);
        }

        // ==========================================
        // PAGE 3: DETAILED ANALYSIS
        // ==========================================
        if (y > H - 120) addPage(); else y += 15;
        drawSectionHeader('Performance Breakdown');

        // 4-Grid of Scores
        const scores = [
            { label: 'Conversion Efficiency', s: profile.scores?.conversionEfficiency?.score, desc: 'Ability to capture leads' },
            { label: 'SEO Strength', s: profile.scores?.seoStrength?.score, desc: 'Search engine visibility' },
            { label: 'Technical Quality', s: profile.scores?.technicalQuality?.score, desc: 'Speed and mobile optimization' },
            { label: 'Sales Opportunity', s: profile.scores?.salesOpportunity?.score, desc: 'Potential for growth' }
        ];

        let gx = M;
        let gy = y;
        const gw = (CW - 10) / 2;
        const gh = 36; // Taller

        scores.forEach((s, i) => {
            // Reset to new row after 2
            if (i === 2) { gx = M; gy += gh + 10; }
            else if (i > 0 && i !== 2) { gx += gw + 10; }

            // Check page break for grid? slightly complex, assuming space for now or simple push
            if (gy + gh > H - 25) { addPage(); gy = y; gx = M; }

            doc.setDrawColor(C.border);
            doc.setFillColor(C.white);
            doc.roundedRect(gx, gy, gw, gh, 3, 3, 'FD');

            // Dot
            doc.setFillColor(getScoreColor(s.s || 0));
            doc.circle(gx + 8, gy + 10, 3, 'F');

            // Name
            doc.setFontSize(10);
            doc.setTextColor(C.textMain);
            doc.setFont('helvetica', 'bold');
            doc.text(String(s.label || ''), gx + 16, gy + 11);

            // Score
            doc.setFontSize(16);
            doc.setTextColor(C.textMain);
            doc.text(`${s.s || 0}/100`, gx + gw - 10, gy + 11, { align: 'right' });

            // Desc
            doc.setFontSize(9);
            doc.setTextColor(C.textMuted);
            doc.setFont('helvetica', 'normal');
            doc.text(String(s.desc || ''), gx + 8, gy + 22);
        });

        y = gy + gh + 20;


        // ==========================================
        // ACTION PLAN (Modern Cards)
        // ==========================================
        drawSectionHeader('Strategic Action Plan');

        const tasks = profile.actionPlan || [];
        if (tasks.length > 0) {
            tasks.forEach((task, i) => {
                const title = String(task.step || 'Action Step');
                const desc = `WHAT: ${task.description || ''}`;
                const why = `WHY: ${task.justification || ''}`;
                const how = `HOW: ${task.implementation || ''}`;
                const meta = `${task.priority || 'Medium'} Priority  •  ${task.impact || 'Medium'} Impact  •  ${task.timeframe || 'TBD'}`;

                // Calculations
                doc.setFontSize(12); doc.setFont('helvetica', 'bold');
                const titleLines = doc.splitTextToSize(title, CW - 20);

                doc.setFontSize(10); doc.setFont('helvetica', 'normal');
                const descLines = doc.splitTextToSize(desc, CW - 20);
                const whyLines = doc.splitTextToSize(why, CW - 20);
                const howLines = doc.splitTextToSize(how, CW - 20);

                doc.setFontSize(9); doc.setFont('helvetica', 'bold');
                const metaLines = doc.splitTextToSize(meta, CW - 20);

                const padding = 6;
                const blockH = 10 + (titleLines.length * 6) + (metaLines.length * 5) + (descLines.length * 5) + (whyLines.length * 5) + (howLines.length * 5) + 12;

                if (y + blockH > H - 25) addPage();

                // Card Background
                doc.setFillColor(C.white);
                doc.setDrawColor(C.border);
                doc.roundedRect(M, y, CW, blockH, 3, 3, 'FD');

                // Accent Stripe left
                doc.setFillColor(C.accent);
                doc.rect(M, y + 4, 1.5, blockH - 8, 'F');

                const txtX = M + 8;
                let curY = y + 8;

                // Title
                doc.setTextColor(C.textMain);
                doc.setFontSize(12); doc.setFont('helvetica', 'bold');
                doc.text(titleLines, txtX, curY);
                curY += titleLines.length * 6;

                // Meta
                doc.setTextColor(C.textSec);
                doc.setFontSize(9); doc.setFont('helvetica', 'bold');
                doc.text(metaLines, txtX, curY);
                curY += metaLines.length * 5 + 3;

                // Details (Lighter text)
                doc.setTextColor(C.textSec);
                doc.setFontSize(10); doc.setFont('helvetica', 'normal');

                doc.text(descLines, txtX, curY);
                curY += descLines.length * 5 + 2;

                doc.text(whyLines, txtX, curY);
                curY += whyLines.length * 5 + 2;

                doc.text(howLines, txtX, curY);

                y += blockH + 8; // Gap between cards
            });
        }

        // ==========================================
        // FINAL PAGE: CONTACT
        // ==========================================
        addPage();
        y = H / 3;

        drawText('Ready to Execute?', 28, C.textMain, 'bold', 'center');
        y += 12;
        drawText('This report identifies the "what" and "why". We specialize in the "how".', 12, C.textSec, 'normal', 'center');

        y += 24;
        doc.setDrawColor(C.accent);
        doc.setLineWidth(0.5);
        doc.line(W / 2 - 25, y, W / 2 + 25, y);
        y += 24;

        // User signature if available (passed in profile or we use defaults)
        drawText('Grww Revenue Intelligence', 16, C.textMain, 'bold', 'center');
        drawText('growth@wegrww.com', 12, C.accent, 'normal', 'center');
        drawText('www.wegrww.com', 12, C.textSec, 'normal', 'center');


        // SAVE
        const filename = (profile.companyName || 'Report').replace(/[^a-zA-Z0-9]/g, '_') + '_Revenue_Intelligence.pdf';
        doc.save(filename);
    };

})();
