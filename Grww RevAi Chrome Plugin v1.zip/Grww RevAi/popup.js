/**
 * Popup Controller — Premium Intelligence UI
 * Score rendering, revenue panel, alerts, sales assist, PDF download, JSON export.
 * v2.2.0 — Enhanced settings, rate limiting, analysis history.
 */
(function () {
    'use strict';

    const isExtCtx = typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.id;

    // HTML escaping — prevents XSS from AI response data
    function esc(str) {
        if (!str) return '';
        const d = document.createElement('div');
        d.textContent = String(str);
        return d.innerHTML;
    }

    // Email validation for mailto: href safety
    function isValidEmail(email) {
        if (!email || typeof email !== 'string') return false;
        return /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(email) && email.length <= 254;
    }

    // Clamp score to valid 0-100 range
    function clampScore(v) { const n = Number(v); return isNaN(n) ? 0 : Math.max(0, Math.min(100, Math.round(n))); }

    // Sensitive keys that must NEVER go to localStorage
    const SENSITIVE_KEYS = new Set(['apiKey']);

    const storage = {
        async get(keys) {
            if (isExtCtx) return chrome.storage.local.get(keys);
            const r = {};
            keys.forEach(k => { if (SENSITIVE_KEYS.has(k)) return; const v = localStorage.getItem('acp_' + k); if (v) r[k] = v; });
            return r;
        },
        async set(obj) {
            if (isExtCtx) return chrome.storage.local.set(obj);
            Object.entries(obj).forEach(([k, v]) => { if (SENSITIVE_KEYS.has(k)) return; localStorage.setItem('acp_' + k, v); });
        }
    };

    // ===== DEMO PROFILE WITH SCORES =====
    const DEMO_PROFILE = {
        companyName: "WeHack.in",
        website: "https://wehack.in",
        industry: "Cybersecurity / Bug Bounty Platform",
        companySize: "11-50 employees",
        founded: "2019",
        headquarters: "Bengaluru, India",
        overview: "WeHack is a premier bug bounty and pentesting platform connecting ethical hackers with enterprises. They show strong community engagement but have significant gaps in enterprise sales conversion and automated lead nurturing.",

        scores: {
            conversionEfficiency: { score: 45, label: "Conversion Efficiency", details: "Leaky funnel: High traffic to sign-up, but low conversion to paid enterprise plans. Pricing page is hidden." },
            seoStrength: { score: 72, label: "SEO Strength", details: "Strong organic traffic for 'bug bounty' keywords, but weak for 'enterprise pentesting services'." },
            technicalQuality: { score: 88, label: "Technical Quality", details: "Excellent site performance and security headers. Modern stack (Next.js), fast TTI." },
            salesOpportunity: { score: 92, label: "Sales Opportunity", details: "High. They have traffic but lack a structured B2B sales motion. Perfect candidate for outbound & CRO." },
            companyHealth: { score: 68, label: "Company Health Index", details: "Solid product-market fit, but revenue growth is throttled by weak monetization pathways." }
        },

        revenueIntelligence: {
            severity: "High",
            estimatedLeakRange: "$120K – $350K / year",
            causes: [
                { cause: "Buried Enterprise Pricing", impact: "High Friction", fix: "Create dedicated /enterprise landing page with clear CTA" },
                { cause: "No Sales Capture", impact: "$50k/mo lost pipeline", fix: "Implement 'Book a Demo' flow for high-ticket leads" },
                { cause: "Weak Email Nurturing", impact: "$30k/mo in churn", fix: "Setup HubSpot workflow for failed signups" }
            ]
        },

        alerts: [
            { severity: "critical", title: "Enterprise Pricing Missing", detail: "Enterprises cannot easily find 'Pentesting as a Service' pricing, causing drop-off to competitors like HackerOne." },
            { severity: "critical", title: "No Book a Demo CTA", detail: "High-value prospects are forced into self-serve hacker flow." },
            { severity: "improvement", title: "Weak Lead Nurturing", detail: "No email sequence for failed signups. 60% of leads churn after 7 days." },
            { severity: "optimized", title: "Strong Community Brand", detail: "Excellent trust signals from hacker community, but not leveraged for B2B trust." }
        ],

        opportunities: [
            { service: "CRO Audit & Funnel Redesign", problem: "Enterprise leads are getting lost in the hacker sign-up flow.", estimatedROI: "High", estimatedBudget: "$15k - $25k", priority: 1 },
            { service: "Outbound Sales System", problem: "No active sales motion to target CISOs directly.", estimatedROI: "High", estimatedBudget: "$5k - $10k/mo", priority: 2 },
            { service: "Marketing Automation", problem: "Missing automated follow-ups for 'Contact Us' submissions.", estimatedROI: "Medium", estimatedBudget: "$5k Setup", priority: 3 }
        ],

        competitors: [
            { name: "HackerOne", website: "hackerone.com", description: "Market leader in bug bounty", marketPosition: "Leader", strengths: "Huge enterprise brand, massive hacker pool", weaknesses: "Expensive, impersonal service", differentiator: "Volume & Brand" },
            { name: "Cobalt", website: "cobalt.io", description: "Pentest as a Service (PtaaS)", marketPosition: "Competitor", strengths: "Fast turnaround, good platform", weaknesses: "Less community focus", differentiator: "Speed & Platform" },
            { name: "Bugcrowd", website: "bugcrowd.com", description: "Crowdsourced security", marketPosition: "Competitor", strengths: "Vintage player, trusted", weaknesses: "Lower innovation velocity", differentiator: "Trust" }
        ],

        marketAnalysis: {
            marketSize: "$5.7B (2025)",
            growthRate: "24.3% CAGR",
            opportunities: ["Compliance (SOC2/ISO) driving pentest demand", "SaaS sprawl increasing attack surfaces"],
            threats: ["AI automated pentesting tools", "Budget cuts in tech"],
            trends: ["PtaaS adoption", "Continuous compliance"]
        },

        keyContacts: [
            { name: "Rahul Sasi", title: "Co-Founder", department: "Executive", email: "rahul@wehack.in", connectionGuide: "Reach via LinkedIn. Reference his security research. Focus on scaling enterprise sales." },
            { name: "Sandeep Singh", title: "Head of Growth", department: "Growth", email: "sandeep@wehack.in", connectionGuide: "Email with 'Enterprise Pipeline' structure. Low friction." }
        ],

        actionPlan: [
            { step: 1, action: "Launch 'Enterprise Pentesting' landing page", contact: "Marketing Team", channel: "Internal", talkingPoints: ["Separate hacker vs buyer funnels", "Add case studies"], timeline: "Week 1" },
            { step: 2, action: "Implement HubSpot/Salesforce integration", contact: "CTO", channel: "Slack", talkingPoints: ["Automate lead scoring"], timeline: "Week 2" },
            { step: 3, action: "Outbound campaign to CISOs in Fintech", contact: "Sales Team", channel: "Apollo", talkingPoints: ["Compliance pressure", "Cost effective vs Big 4"], timeline: "Week 3" }
        ],

        keyPeople: [
            { name: "Rithik", role: "Decision Maker", email: "rithik@wehack.in" }
        ],

        salesAssist: {
            coldEmailHook: "Your 'Hacker' signup flow is cannibalizing your Enterprise leads — losing ~$20k/mo.",
            linkedinOpener: "Huge fan of WeHack's community work. Noticed a massive gap in how you capture Enterprise clients vs researchers.",

            coldEmail: "Subject: Losing Enterprise leads on wehack.in?\n\nHi Rithik,\n\nBig fan of the community you've built at WeHack. I've been tracking your growth and noticed a critical bottleneck: your current signup flow treats CISOs and Hackers exactly the same.\n\nYou're likely losing ~$20k/mo in enterprise pipeline because high-value buyers can't easily find a 'Book Demo' or 'Enterprise' path.\n\nWe helped a similar cybersecurity platform fix this by splitting the funnel, resulting in a 40% bump in qualified demos.\n\nOpen to a 5-min video audit on this?\n\nBest,\n[Your Name]",

            linkedinDM: "Hey Rithik, huge respect for what you've built with WeHack. \n\nI was looking at your site and noticed you're ranking great for researcher keywords, but your 'Enterprise Pentesting' pages are buried. You're likely leaving serious ACV on the table to competitors like Cobalt.\n\nI have a few ideas on how to capture that demand without hurting the community vibe. Worth a quick chat?",

            whatsappDM: "Hey! 👋 Quick one — I was checking out WeHack.in and noticed something interesting.\n\nYour community side is 🔥 but the enterprise pricing page is basically hidden. CISOs land on the same hacker signup flow and bounce.\n\nWe recently helped a similar cybersecurity platform fix this exact issue — they saw a 40% jump in enterprise demos in 90 days.\n\nWould you be open to a quick 10-min call this week? I can share the specific playbook we used. No pitch, just value 🤝",

            auditPitch: "WEHACK.IN — REVENUE & CONVERSION AUDIT\n\nEXECUTIVE SUMMARY:\nWeHack.in has achieved dominant community positioning but is under-monetizing its enterprise traffic. The primary revenue leak is the lack of a distinct B2B sales funnel.\n\nCRITICAL ISSUES:\n1. Universal Signup Flow: CISOs are forced through a 'Hacker' registration process.\n2. Buried Pricing: Enterprise tiers are not visible, reducing perceived value.\n3. Missing Trust Signals: Case studies are hidden in the blog rather than on a dedicated solution page.\n\nRECOMMENDED ACTIONS:\n- Launch /enterprise sub-folder with dedicated value prop.\n- Implement 'Book a Demo' CTA for specific IP ranges.\n- Setup retargeting for visitors who hit the 'Business' page but didn't convert.",

            proposalOutline: "PROJECT PROPOSAL: ENTERPRISE FUNNEL OPTIMIZATION\n\nOBJECTIVE:\nTransform WeHack.in from a community-first site into a dual-funnel platform that captures high-value enterprise accounts without alienating the hacker community.\n\nSCOPE OF WORK:\n1. UX/UI Redesign of Landing Page (Split Funnel).\n2. HubSpot Implementation for Lead Scoring.\n3. Cold Outreach System Setup (Apollo + Instantly).\n\nINVESTMENT:\n$18,500 One-time + $3,000/mo retainer for optimization.\n\nTIMELINE:\n4 Weeks to Launch.\n\nEXPECTED OUTCOME:\n30-50% increase in qualified Enterprise Demos within 60 days."
        }
    };

    // ===== DOM =====
    const $ = id => document.getElementById(id);
    const els = {
        settingsToggle: $('settingsToggle'), settingsPanel: $('settingsPanel'),
        historyToggle: $('historyToggle'), historyPanel: $('historyPanel'),
        historyList: $('historyList'), clearHistory: $('clearHistory'),
        provider: $('provider'), apiKey: $('apiKey'), model: $('model'),
        baseUrl: $('baseUrl'), baseUrlGroup: $('baseUrlGroup'),
        temperature: $('temperature'), tempValue: $('tempValue'),
        maxTokens: $('maxTokens'), timeout: $('timeout'),
        maxRequestsPerMin: $('maxRequestsPerMin'), exportFormat: $('exportFormat'),
        saveHistory: $('saveHistory'),
        saveSettings: $('saveSettings'), settingsStatus: $('settingsStatus'),
        toggleKeyVisibility: $('toggleKeyVisibility'),
        siteBadge: $('siteBadge'), currentSite: $('currentSite'),
        rateLimitBadge: $('rateLimitBadge'), rateLimitText: $('rateLimitText'),
        actionCard: $('actionCard'),
        analyzeBtn: $('analyzeBtn'), demoBtn: $('demoBtn'),
        progressArea: $('progressArea'), progressFill: $('progressFill'), progressText: $('progressText'),
        errorArea: $('errorArea'), errorText: $('errorText'),
        resultsArea: $('resultsArea'),
        companyName: $('companyName'), companyDomain: $('companyDomain'), industryBadge: $('industryBadge'),
        chiGauge: $('chiGauge'), chiGaugeFill: $('chiGaugeFill'), chiValue: $('chiValue'),
        scoresGrid: $('scoresGrid'),
        revenuePanel: $('revenuePanel'), revenueSeverity: $('revenueSeverity'),
        revenueAmount: $('revenueAmount'), revenueCauses: $('revenueCauses'),
        keyPeopleSection: $('keyPeopleSection'), keyPeopleList: $('keyPeopleList'),
        alertsList: $('alertsList'), oppsList: $('oppsList'),
        salesModal: $('salesModal'), salesModalTitle: $('salesModalTitle'),
        salesModalContent: $('salesModalContent'),
        copySalesContent: $('copySalesContent'), closeSalesModal: $('closeSalesModal'),
        downloadPdf: $('downloadPdf'), exportJson: $('exportJson'), analyzeAnother: $('analyzeAnother'),
        // Profile
        profileName: $('profileName'), profileEmail: $('profileEmail'),
        profileCompany: $('profileCompany'), profileRole: $('profileRole'),
        profilePhone: $('profilePhone'), profileLinkedin: $('profileLinkedin'),
        profileSignature: $('profileSignature'),
        profileAvatar: $('profileAvatar'), profilePreviewName: $('profilePreviewName'),
        profilePreviewCompany: $('profilePreviewCompany'),
        // Email service
        emailProvider: $('emailProvider'), emailApiKey: $('emailApiKey'),
        emailApiKeyGroup: $('emailApiKeyGroup'), emailDomainGroup: $('emailDomainGroup'),
        emailEndpointGroup: $('emailEndpointGroup'), emailRegionGroup: $('emailRegionGroup'),
        emailDomain: $('emailDomain'), emailEndpoint: $('emailEndpoint'), emailRegion: $('emailRegion'),
        toggleEmailKeyVisibility: $('toggleEmailKeyVisibility'),
        // Send email
        sendEmailBtn: $('sendEmailBtn'), sendEmailBar: $('sendEmailBar'),
        recipientEmail: $('recipientEmail'), sendEmailStatus: $('sendEmailStatus'),
        sendWhatsAppBtn: $('sendWhatsAppBtn'),
    };

    let currentProfile = null;
    let isDemoMode = false;

    // ===== PROVIDER MODELS =====
    const MODELS = {
        openai: ['gpt-4o', 'gpt-4o-mini', 'gpt-4-turbo'],
        anthropic: ['claude-sonnet-4-20250514', 'claude-3-5-haiku-20241022', 'claude-3-opus-20240229'],
        gemini: ['gemini-2.0-flash', 'gemini-1.5-pro', 'gemini-1.5-flash'],
        digitalocean: ['deepseek-r1-distill-llama-70b', 'llama3.3-70b-instruct', 'mistral-small-24b-instruct-2501'],
        custom: ['custom-model'],
    };

    // ===== INIT =====
    async function init() {
        await loadSettings();
        setupEvents();
        updateModels();
        detectSite();
        updateRateLimitBadge();
        updateExportButtons();
    }

    async function detectSite() {
        if (!isExtCtx) { els.currentSite.textContent = 'demo mode'; return; }
        try {
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            if (tab?.url) {
                els.currentSite.textContent = new URL(tab.url).hostname;
                els.siteBadge.classList.add('active');
            }
        } catch { els.currentSite.textContent = 'no site detected'; }
    }

    async function loadSettings() {
        try {
            const s = await storage.get([
                'provider', 'apiKey', 'model', 'baseUrl',
                'temperature', 'maxTokens', 'timeout',
                'maxRequestsPerMin', 'exportFormat', 'saveHistory',
                'profileName', 'profileEmail', 'profileCompany', 'profileRole', 'profilePhone', 'profileLinkedin',
                'emailProvider', 'emailApiKey', 'emailDomain', 'emailEndpoint', 'emailRegion'
            ]);

            // Sync Fallback: If local is empty/missing key, try sync
            if (isExtCtx && !s.apiKey) {
                try {
                    const sync = await chrome.storage.sync.get(null); // Get all
                    if (sync.apiKey) {
                        s = { ...s, ...sync };
                        await chrome.storage.local.set(s); // Heal local
                        flash('Restored from sync', 'success');
                    }
                } catch (e) { console.warn('Sync read failed', e); }
            }
            if (s.provider) els.provider.value = s.provider;
            if (s.apiKey) els.apiKey.value = s.apiKey;
            if (s.baseUrl) els.baseUrl.value = s.baseUrl;
            if (s.temperature !== undefined) {
                els.temperature.value = s.temperature;
                els.tempValue.textContent = s.temperature;
            }
            if (s.maxTokens) els.maxTokens.value = s.maxTokens;
            if (s.timeout) els.timeout.value = s.timeout;
            if (s.maxRequestsPerMin) els.maxRequestsPerMin.value = s.maxRequestsPerMin;
            if (s.exportFormat) els.exportFormat.value = s.exportFormat;
            if (s.saveHistory !== undefined) els.saveHistory.checked = s.saveHistory !== 'false';

            // Profile fields
            if (s.profileName) els.profileName.value = s.profileName;
            if (s.profileEmail) els.profileEmail.value = s.profileEmail;
            if (s.profileCompany) els.profileCompany.value = s.profileCompany;
            if (s.profileRole) els.profileRole.value = s.profileRole;
            if (s.profilePhone) els.profilePhone.value = s.profilePhone;
            if (s.profileLinkedin) els.profileLinkedin.value = s.profileLinkedin;
            if (s.profileSignature) els.profileSignature.value = s.profileSignature;
            updateProfilePreview();

            // Email service fields
            if (s.emailProvider) els.emailProvider.value = s.emailProvider;
            if (s.emailApiKey) els.emailApiKey.value = s.emailApiKey;
            if (s.emailDomain) els.emailDomain.value = s.emailDomain;
            if (s.emailEndpoint) els.emailEndpoint.value = s.emailEndpoint;
            if (s.emailRegion) els.emailRegion.value = s.emailRegion;
            updateEmailProviderUI();

            updateModels();
            if (s.model) els.model.value = s.model;
            updateBaseUrl();
            if (!s.apiKey) { els.settingsPanel.classList.add('open'); els.settingsToggle.classList.add('active'); }
        } catch { els.settingsPanel.classList.add('open'); }
    }

    function setupEvents() {
        // Settings toggle
        els.settingsToggle.addEventListener('click', () => {
            els.settingsPanel.classList.toggle('open');
            els.settingsToggle.classList.toggle('active');
            // Close history if open
            els.historyPanel.classList.remove('open');
            els.historyToggle.classList.remove('active');
        });

        // History toggle
        els.historyToggle.addEventListener('click', () => {
            els.historyPanel.classList.toggle('open');
            els.historyToggle.classList.toggle('active');
            // Close settings if open
            els.settingsPanel.classList.remove('open');
            els.settingsToggle.classList.remove('active');
            if (els.historyPanel.classList.contains('open')) loadHistory();
        });

        els.clearHistory.addEventListener('click', clearHistory);

        els.provider.addEventListener('change', () => { updateModels(); updateBaseUrl(); });
        els.toggleKeyVisibility.addEventListener('click', () => {
            els.apiKey.type = els.apiKey.type === 'password' ? 'text' : 'password';
        });

        // Temperature slider live update
        els.temperature.addEventListener('input', () => {
            els.tempValue.textContent = els.temperature.value;
        });

        // Profile live preview
        els.profileName.addEventListener('input', updateProfilePreview);
        els.profileCompany.addEventListener('input', updateProfilePreview);

        // Email provider toggle
        els.emailProvider.addEventListener('change', updateEmailProviderUI);
        if (els.toggleEmailKeyVisibility) {
            els.toggleEmailKeyVisibility.addEventListener('click', () => {
                els.emailApiKey.type = els.emailApiKey.type === 'password' ? 'text' : 'password';
            });
        }

        // Auto-detect provider from key
        els.apiKey.addEventListener('input', () => {
            const k = els.apiKey.value.trim();
            let p = '';
            if (k.startsWith('sk-do')) p = 'digitalocean';
            else if (k.startsWith('sk-proj') || k.startsWith('sk-org')) p = 'openai';
            else if (k.startsWith('sk-ant')) p = 'anthropic';
            else if (k.startsWith('AIza')) p = 'gemini';

            if (p) {
                if (els.provider.value !== p) {
                    els.provider.value = p;
                    updateModels();
                    updateBaseUrl();
                    flash(`Auto-switched to ${p}`, 'success');
                }
            }
        });

        // Send email
        els.sendEmailBtn.addEventListener('click', handleSendEmailClick);

        // Send WhatsApp
        els.sendWhatsAppBtn.addEventListener('click', () => {
            const content = els.salesModalContent.textContent;
            const phone = els.sendWhatsAppBtn.dataset.phone || '';
            const url = `https://wa.me/${phone}?text=${encodeURIComponent(content)}`;
            window.open(url, '_blank');
        });

        els.saveSettings.addEventListener('click', saveSettings);
        els.analyzeBtn.addEventListener('click', analyzeWebsite);
        els.demoBtn.addEventListener('click', runDemo);
        els.downloadPdf.addEventListener('click', downloadPDF);
        els.exportJson.addEventListener('click', exportJSON);
        els.analyzeAnother.addEventListener('click', resetUI);

        // Sales assist buttons
        document.querySelectorAll('.sales-btn').forEach(btn => {
            btn.addEventListener('click', () => generateSalesContent(btn.dataset.type));
        });
        els.closeSalesModal.addEventListener('click', () => els.salesModal.classList.remove('open'));
        els.copySalesContent.addEventListener('click', () => {
            navigator.clipboard.writeText(els.salesModalContent.textContent);
            els.copySalesContent.innerHTML = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="var(--green)" stroke-width="2"><polyline points="20,6 9,17 4,12"/></svg>';
            setTimeout(() => {
                els.copySalesContent.innerHTML = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1"/></svg>';
            }, 2000);
        });
    }

    function updateModels() {
        const models = MODELS[els.provider.value] || ['custom-model'];
        els.model.innerHTML = '';
        models.forEach(m => { const o = document.createElement('option'); o.value = m; o.textContent = m; els.model.appendChild(o); });
    }

    function updateBaseUrl() {
        const p = els.provider.value;
        const show = (p === 'digitalocean' || p === 'custom');
        els.baseUrlGroup.style.display = show ? 'block' : 'none';

        if (p === 'digitalocean') {
            const current = els.baseUrl.value;
            // Auto-fill if empty or if it looks like an old default
            if (!current || current.includes('openai.com')) {
                els.baseUrl.value = 'https://inference.do-ai.run/v1';
            }
        } else if (p === 'openai' || p === 'anthropic' || p === 'gemini') {
            els.baseUrl.value = '';
        }
    }

    function updateExportButtons() {
        const fmt = els.exportFormat.value;
        els.exportJson.style.display = (fmt === 'both') ? 'flex' : 'none';
    }

    async function updateRateLimitBadge() {
        if (!isExtCtx) {
            els.rateLimitText.textContent = '∞';
            return;
        }
        try {
            const result = await chrome.runtime.sendMessage({ action: 'getRateLimitStatus' });
            if (result?.success) {
                const { remaining, limit } = result.data;
                els.rateLimitText.textContent = `${remaining}/${limit}`;
                els.rateLimitBadge.classList.toggle('rate-low', remaining <= 2);
                els.rateLimitBadge.classList.toggle('rate-empty', remaining === 0);
            }
        } catch { els.rateLimitText.textContent = '—'; }
    }

    async function saveSettings() {
        const VALID_PROVIDERS = new Set(['openai', 'anthropic', 'gemini', 'digitalocean', 'custom']);
        const provider = els.provider.value;
        if (!VALID_PROVIDERS.has(provider)) { flash('Invalid provider', 'error'); return; }

        const apiKey = els.apiKey.value.trim();
        if (!apiKey) { flash('Please enter an API key', 'error'); return; }
        if (apiKey.length < 10) { flash('API key looks too short', 'error'); return; }
        if (apiKey.length > 256) { flash('API key too long (max 256 chars)', 'error'); return; }

        // Validate base URL if present
        const baseUrl = els.baseUrl.value.trim();
        if (baseUrl) {
            try {
                const parsed = new URL(baseUrl);
                if (parsed.protocol !== 'https:') {
                    flash('Base URL must use HTTPS', 'error');
                    return;
                }
            } catch {
                flash('Invalid Base URL format', 'error');
                return;
            }
        }

        const s = {
            provider,
            apiKey,
            model: els.model.value,
            baseUrl: baseUrl,
            temperature: els.temperature.value,
            maxTokens: els.maxTokens.value,
            timeout: els.timeout.value,
            maxRequestsPerMin: els.maxRequestsPerMin.value,
            exportFormat: els.exportFormat.value,
            saveHistory: els.saveHistory.checked ? 'true' : 'false',
            // Profile
            profileName: els.profileName.value.trim(),
            profileEmail: els.profileEmail.value.trim(),
            profileCompany: els.profileCompany.value.trim(),
            profileRole: els.profileRole.value.trim(),
            profilePhone: els.profilePhone.value.trim(),
            profileLinkedin: els.profileLinkedin.value.trim(),
            profileSignature: els.profileSignature.value.trim(),
            // Email service
            emailProvider: els.emailProvider.value,
            emailApiKey: els.emailApiKey.value.trim(),
            emailDomain: els.emailDomain.value.trim(),
            emailEndpoint: els.emailEndpoint.value.trim(),
            emailRegion: els.emailRegion.value.trim(),
        };

        try {
            if (isExtCtx) {
                // Dual save to local and sync for reliability
                await chrome.storage.local.set(s);
                try { await chrome.storage.sync.set(s); } catch (e) { console.warn('Sync save failed', e); }

                // Verify write (check local first)
                const verify = await chrome.storage.local.get(['apiKey']);
                if (verify.apiKey !== s.apiKey) {
                    throw new Error('Storage write failed. Please check extension permissions.');
                }
            } else {
                const { apiKey: _key, ...safe } = s;
                Object.entries(safe).forEach(([k, v]) => localStorage.setItem('acp_' + k, v));
                flash('Note: API key only stored when loaded as extension', 'error');
                return;
            }
            flash('Saved ✓', 'success');
            updateExportButtons();
            updateRateLimitBadge();
            setTimeout(() => { els.settingsPanel.classList.remove('open'); els.settingsToggle.classList.remove('active'); }, 800);
        } catch (e) { flash('Error: ' + e.message, 'error'); }
    }

    function flash(msg, type) {
        els.settingsStatus.textContent = msg;
        els.settingsStatus.className = `status-msg ${type}`;
        setTimeout(() => { els.settingsStatus.className = 'status-msg'; }, 3000);
    }

    // ===== PROFILE PREVIEW =====
    function updateProfilePreview() {
        const name = els.profileName.value.trim();
        const company = els.profileCompany.value.trim();
        if (name) {
            els.profileAvatar.textContent = name.charAt(0).toUpperCase();
            els.profilePreviewName.textContent = name;
            els.profilePreviewCompany.textContent = company || 'No company set';
        } else {
            els.profileAvatar.textContent = '?';
            els.profilePreviewName.textContent = 'Not configured';
            els.profilePreviewCompany.textContent = 'Set your profile to personalize outreach';
        }
    }

    // ===== EMAIL PROVIDER UI =====
    function updateEmailProviderUI() {
        const val = els.emailProvider.value;
        const showKey = val !== 'none';
        els.emailApiKeyGroup.style.display = showKey ? '' : 'none';
        els.emailDomainGroup.style.display = val === 'mailgun' ? '' : 'none';
        els.emailRegionGroup.style.display = val === 'ses' ? '' : 'none';
        els.emailEndpointGroup.style.display = val === 'custom' ? '' : 'none';
    }

    // ===== SEND EMAIL =====
    let currentSalesType = null;

    async function handleSendEmailClick() {
        const recipient = els.recipientEmail.value.trim();
        if (!recipient || !/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(recipient)) {
            els.sendEmailStatus.textContent = 'Invalid email';
            els.sendEmailStatus.className = 'send-email-status error';
            return;
        }

        const content = els.salesModalContent.textContent;
        if (!content || content === 'Generating...') return;

        // Parse SUBJECT line from cold email
        let subject = 'Intro — ' + (currentProfile?.companyName || 'Growth Opportunity');
        let body = content;
        const subjectMatch = content.match(/^SUBJECT:\s*(.+)/i);
        if (subjectMatch) {
            subject = subjectMatch[1].trim();
            body = content.substring(content.indexOf('\n', content.indexOf(subjectMatch[0]))).trim();
        }

        els.sendEmailBtn.disabled = true;
        els.sendEmailStatus.textContent = 'Sending…';
        els.sendEmailStatus.className = 'send-email-status';

        if (!isExtCtx || isDemoMode) {
            // Demo / non-extension fallback
            await sleep(800);
            els.sendEmailStatus.textContent = '✓ Sent (demo)';
            els.sendEmailStatus.className = 'send-email-status success';
            els.sendEmailBtn.disabled = false;
            return;
        }

        try {
            const result = await chrome.runtime.sendMessage({
                action: 'sendEmail',
                to: recipient,
                subject: subject,
                body: body
            });
            if (result?.success) {
                els.sendEmailStatus.textContent = '✓ Sent!';
                els.sendEmailStatus.className = 'send-email-status success';
            } else {
                els.sendEmailStatus.textContent = result?.error || 'Failed';
                els.sendEmailStatus.className = 'send-email-status error';
            }
        } catch (e) {
            els.sendEmailStatus.textContent = e.message;
            els.sendEmailStatus.className = 'send-email-status error';
        }
        els.sendEmailBtn.disabled = false;
    }

    // ===== HISTORY =====
    async function loadHistory() {
        if (!isExtCtx) {
            els.historyList.innerHTML = '<div class="history-empty">History is only available as a Chrome extension.</div>';
            return;
        }
        try {
            const result = await chrome.runtime.sendMessage({ action: 'getAnalysisHistory' });
            if (!result?.success || !result.data?.length) {
                els.historyList.innerHTML = '<div class="history-empty">No analyses yet. Analyze a website to get started.</div>';
                return;
            }
            els.historyList.innerHTML = '';
            result.data.forEach((entry, idx) => {
                const div = document.createElement('div');
                div.className = 'history-item';
                const date = new Date(entry.analyzedAt);
                const timeStr = date.toLocaleDateString() + ' ' + date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
                const chiClass = entry.chiScore >= 75 ? 'score-green' : entry.chiScore >= 40 ? 'score-amber' : 'score-red';
                div.innerHTML = `
                    <div class="history-item-info">
                        <span class="history-item-name">${esc(entry.companyName)}</span>
                        <span class="history-item-meta">${esc(entry.website)} · ${esc(timeStr)}</span>
                    </div>
                    <span class="history-item-score ${chiClass}">${parseInt(entry.chiScore, 10) || 0}</span>
                `;
                div.addEventListener('click', () => {
                    currentProfile = entry.profile;
                    isDemoMode = false;
                    renderResults(currentProfile);
                    els.historyPanel.classList.remove('open');
                    els.historyToggle.classList.remove('active');
                });
                els.historyList.appendChild(div);
            });
        } catch {
            els.historyList.innerHTML = '<div class="history-empty">Failed to load history.</div>';
        }
    }

    async function clearHistory() {
        if (!isExtCtx) return;
        try {
            await chrome.runtime.sendMessage({ action: 'clearAnalysisHistory' });
            els.historyList.innerHTML = '<div class="history-empty">History cleared.</div>';
        } catch { /* ignore */ }
    }

    // ===== ANALYSIS FLOW =====
    // ===== OPEN DASHBOARD IN NEW TAB =====
    async function openDashboard(profileData) {
        if (!isExtCtx || !profileData) return;
        try {
            await chrome.storage.local.set({ latestDashboardProfile: profileData });
            chrome.tabs.create({ url: chrome.runtime.getURL('dashboard.html') });
        } catch (e) {
            console.warn('Could not open dashboard tab:', e);
        }
    }

    async function analyzeWebsite() {
        isDemoMode = false;
        if (!isExtCtx) { showError('Load as Chrome extension first. Use "Try Demo Mode" to preview.'); return; }
        const s = await storage.get(['apiKey']);
        if (!s.apiKey) { showError('Configure your API key first (⚙ icon).'); return; }

        setLoading(true); hideError(); hideResults();

        try {
            showProgress('Detecting website...', 5);
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            if (!tab?.url || tab.url.startsWith('chrome://') || tab.url.startsWith('chrome-extension://')) {
                throw new Error('Navigate to a company website first.');
            }

            showProgress('Scanning website...', 15);
            let websiteData;
            try {
                const r = await chrome.tabs.sendMessage(tab.id, { action: 'extractWebsite' });
                if (!r?.success) throw new Error();
                websiteData = r.data;
            } catch {
                await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['content.js'] });
                await sleep(500);
                const r = await chrome.tabs.sendMessage(tab.id, { action: 'extractWebsite' });
                if (!r?.success) throw new Error('Failed to read website. Try refreshing.');
                websiteData = r.data;
            }

            showProgress('Running intelligence analysis — 15-30s...', 40);
            const result = await chrome.runtime.sendMessage({ action: 'analyzeWebsite', websiteData });
            if (!result?.success) throw new Error(result?.error || 'Analysis failed.');

            showProgress('Building dashboard...', 90);
            await sleep(300);

            currentProfile = result.data;
            renderResults(currentProfile);
            setLoading(false);
            updateRateLimitBadge();

            // Store profile and open full dashboard in new tab
            await openDashboard(currentProfile);

        } catch (e) { setLoading(false); hideProgress(); showError(e.message); updateRateLimitBadge(); }
    }

    async function runDemo() {
        setLoading(true); hideError(); hideResults();
        showProgress('Scanning demo website...', 20); await sleep(400);
        showProgress('Running intelligence analysis...', 50); await sleep(500);
        showProgress('Scoring & diagnostics...', 75); await sleep(400);
        showProgress('Building dashboard...', 95); await sleep(300);

        isDemoMode = true;
        currentProfile = DEMO_PROFILE;
        renderResults(currentProfile);
        setLoading(false);

        // Store demo profile and open full dashboard
        await openDashboard(currentProfile);
    }

    // ===== RENDER RESULTS =====
    function renderResults(p) {
        hideProgress();
        els.actionCard.style.display = 'none';
        els.siteBadge.style.display = 'none';

        // Header
        els.companyName.textContent = p.companyName || 'Unknown';
        els.companyDomain.textContent = p.website || '—';
        els.industryBadge.textContent = p.industry || 'N/A';

        // CHI Gauge
        const chi = clampScore(p.scores?.companyHealth?.score);
        renderGauge(chi);

        // Score Bars
        renderScoreBars(p.scores);

        // Revenue Intelligence
        renderRevenue(p.revenueIntelligence);

        // Key People
        renderKeyPeople(p.keyPeople);

        // Alerts
        renderAlerts(p.alerts);

        // Opportunities
        renderOpportunities(p.opportunities);

        // Show/hide export buttons based on settings
        updateExportButtons();

        els.resultsArea.style.display = 'block';
    }

    function renderGauge(score) {
        const circumference = 2 * Math.PI * 30; // r=30
        const offset = circumference - (score / 100) * circumference;
        els.chiGaugeFill.style.strokeDasharray = circumference;

        // FIX: Remove old gauge color classes before adding new one
        els.chiGaugeFill.classList.remove('gauge-green', 'gauge-amber', 'gauge-red');

        setTimeout(() => {
            els.chiGaugeFill.style.strokeDashoffset = offset;
            els.chiGaugeFill.classList.add(scoreGaugeClass(score));
        }, 100);
        els.chiValue.textContent = score;
        els.chiValue.className = `chi-gauge-value ${scoreColorClass(score)}`;
    }

    function renderScoreBars(scores) {
        if (!scores) return;
        const order = ['salesOpportunity', 'conversionEfficiency', 'seoStrength', 'technicalQuality'];
        els.scoresGrid.innerHTML = '';

        order.forEach(key => {
            const s = scores[key];
            if (!s) return;
            const score = clampScore(s.score);
            const row = document.createElement('div');
            row.className = 'score-row';
            row.innerHTML = `
        <span class="score-label">${esc(s.label)}</span>
        <div class="score-bar-track"><div class="score-bar-fill ${scoreFillClass(score)}" style="width:0%"></div></div>
        <span class="score-value ${scoreColorClass(score)}">${score}</span>
      `;
            row.title = esc(s.details) || '';
            els.scoresGrid.appendChild(row);

            // Animate
            setTimeout(() => {
                row.querySelector('.score-bar-fill').style.width = `${score}%`;
            }, 150);
        });
    }

    function renderRevenue(rev) {
        if (!rev) { els.revenuePanel.style.display = 'none'; return; }
        els.revenuePanel.style.display = 'block';

        const sev = (rev.severity || 'medium').toLowerCase();
        els.revenueSeverity.textContent = rev.severity;
        els.revenueSeverity.className = `revenue-severity severity-${sev}`;
        els.revenueAmount.textContent = rev.estimatedLeakRange || '—';

        els.revenueCauses.innerHTML = '';
        (rev.causes || []).forEach(c => {
            const li = document.createElement('li');
            li.innerHTML = `<span class="revenue-cause-label">${esc(c.cause)}</span> — ${esc(c.impact)}`;
            els.revenueCauses.appendChild(li);
        });
    }

    function renderAlerts(alerts) {
        if (!alerts?.length) return;
        els.alertsList.innerHTML = '';
        const validSeverities = new Set(['critical', 'improvement', 'optimized']);
        alerts.forEach(a => {
            const div = document.createElement('div');
            div.className = 'alert-item';
            const severity = validSeverities.has(a.severity) ? a.severity : 'improvement';
            div.innerHTML = `
        <span class="alert-dot ${severity}"></span>
        <div class="alert-content">
          <div class="alert-title-text">${esc(a.title)}</div>
          <div class="alert-detail">${esc(a.detail)}</div>
        </div>
      `;
            els.alertsList.appendChild(div);
        });
    }

    function renderKeyPeople(people) {
        if (!people?.length) { els.keyPeopleSection.style.display = 'none'; return; }
        els.keyPeopleSection.style.display = 'block';
        els.keyPeopleList.innerHTML = '';
        people.forEach(p => {
            const div = document.createElement('div');
            div.className = 'person-item';
            div.style.cssText = 'display:flex; justify-content:space-between; align-items:center; background:var(--bg-2); padding:8px 12px; border-radius:6px; margin-bottom:6px; border:1px solid var(--border-1);';
            // FIX: Validate email format before creating mailto: link to prevent injection
            const emailLink = (p.email && isValidEmail(p.email))
                ? `<a href="mailto:${esc(p.email)}" style="color:var(--accent); text-decoration:none; font-size:11px;">${esc(p.email)}</a>`
                : (p.email ? `<span style="color:var(--text-2); font-size:11px;">${esc(p.email)}</span>` : '');
            div.innerHTML = `
                <div style="display:flex; flex-direction:column;">
                    <span style="font-weight:600; font-size:12px; color:var(--text-0);">${esc(p.name)}</span>
                    <span style="font-size:11px; color:var(--text-2);">${esc(p.role)}</span>
                </div>
                ${emailLink}
            `;
            els.keyPeopleList.appendChild(div);
        });
    }

    function renderOpportunities(opps) {
        if (!opps?.length) return;
        els.oppsList.innerHTML = '';
        const validRoi = new Set(['high', 'medium', 'low']);
        opps.sort((a, b) => (a.priority || 99) - (b.priority || 99)).forEach(o => {
            const div = document.createElement('div');
            div.className = 'opp-item';
            const roi = validRoi.has((o.estimatedROI || '').toLowerCase()) ? o.estimatedROI.toLowerCase() : 'medium';
            const roiClass = `roi-${roi}`;
            div.innerHTML = `
        <div class="opp-info">
          <div class="opp-service">${esc(o.service)}</div>
          <div class="opp-problem">${esc(o.problem)}</div>
        </div>
        <div class="opp-meta">
          <span class="opp-roi ${roiClass}">${esc(o.estimatedROI)} ROI</span>
          <div class="opp-budget">${esc(o.estimatedBudget)}</div>
        </div>
      `;
            els.oppsList.appendChild(div);
        });
    }

    // ===== SALES ASSIST =====
    async function generateSalesContent(type) {
        if (!currentProfile) return;
        currentSalesType = type;

        const labels = { coldEmail: 'Cold Email', linkedinDM: 'LinkedIn DM Sequence', whatsappDM: 'WhatsApp Message', auditPitch: 'Audit Pitch', proposalOutline: 'Proposal Outline' };
        els.salesModalTitle.textContent = labels[type] || 'Generated Content';
        els.salesModalContent.textContent = 'Generating...';
        els.salesModal.classList.add('active');

        // Show/hide send email UI for cold email
        const isColdEmail = type === 'coldEmail';
        els.sendEmailBtn.style.display = isColdEmail ? '' : 'none';
        els.sendEmailBar.style.display = isColdEmail ? '' : 'none';
        els.sendEmailStatus.textContent = '';
        els.sendEmailStatus.className = 'send-email-status';

        // Show/hide WhatsApp button
        const isWA = type === 'whatsappDM';
        els.sendWhatsAppBtn.style.display = isWA ? '' : 'none';

        if (isWA) {
            // Try to scrape phone
            try {
                const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
                if (tab?.id) {
                    // Inject content script if not already there
                    await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['content.js'] });
                    const r = await chrome.tabs.sendMessage(tab.id, { action: 'extractDetails' });
                    if (r && r.phones && r.phones.length > 0) {
                        els.salesModalTitle.textContent += ` (Found: ${r.phones[0]})`;
                        els.sendWhatsAppBtn.dataset.phone = r.phones[0].replace(/[^\d]/g, '');
                    }
                }
            } catch (e) { console.warn('Phone scrape failed', e); }
        }

        // Pre-fill recipient from contacts if available
        if (isColdEmail && currentProfile?.keyPeople?.length) {
            const contact = currentProfile.keyPeople.find(p => p.email) || {};
            els.recipientEmail.value = contact.email || '';
        }

        // DEMO MODE BYPASS: Return pre-generated content instantly
        if (isDemoMode && currentProfile.salesAssist && currentProfile.salesAssist[type]) {
            setTimeout(() => {
                els.salesModalContent.textContent = currentProfile.salesAssist[type];
            }, 600);
            return;
        }

        // Disable all sales buttons
        document.querySelectorAll('.sales-btn').forEach(b => b.disabled = true);

        try {
            if (isDemoMode || !isExtCtx) {
                // Demo fallback
                await sleep(800);
                const demoContent = getDemoSalesContent(type);
                els.salesModalContent.textContent = demoContent;
            } else {
                const result = await chrome.runtime.sendMessage({
                    action: 'generateSalesContent',
                    contentType: type,
                    profile: currentProfile
                });
                if (!result?.success) throw new Error(result?.error || 'Generation failed.');
                // Format content: Sanitize FIRST, then apply markdown
                let safeText = esc(result.data); // Prevent XSS
                let formatted = safeText
                    .replace(/^### (.*$)/gim, '<h3>$1</h3>')
                    .replace(/^## (.*$)/gim, '<h4>$1</h4>')
                    .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
                    .replace(/\*(.*?)\*/g, '<em>$1</em>')
                    .replace(/\n/g, '<br>');

                els.salesModalContent.innerHTML = formatted;
            }
        } catch (e) {
            els.salesModalContent.textContent = `Error: ${e.message}`;
        }

        document.querySelectorAll('.sales-btn').forEach(b => b.disabled = false);
        updateRateLimitBadge();
    }

    function getDemoSalesContent(type) {
        const content = {
            coldEmail: `SUBJECT: Your pricing page is leaving $60K/year on the table\n\nHi Marcus,\n\nI was reviewing TechVista's website and noticed something your team might want to know about.\n\nYour primary CTA is below the fold on most landing pages, and your pricing page doesn't have a competitive comparison or ROI calculator. Based on similar SaaS companies we've worked with, this pattern typically results in $60K–$120K/year in lost conversions from evaluators who leave to compare alternatives.\n\nWe recently helped a Series B cloud infrastructure company increase their pricing page conversion by 340% in 90 days by restructuring their CTA hierarchy and adding interactive ROI tools.\n\nWould a 15-minute call next week make sense to discuss? I can share the specific changes that drove those results.\n\nBest,\n[Your name]`,

            linkedinDM: `MESSAGE 1 (Connection Request):\nHi Marcus — noticed TechVista's momentum post-Series B. We work with cloud infra companies on growth strategy. Would love to connect.\n\nMESSAGE 2 (Follow-up, Day 3):\nThanks for connecting. Just saw TechVista's latest post on multi-cloud orchestration. Quick thought: your pricing page is strong technically but missing a competitive comparison section — that one change drove 40% more conversions for a similar client. Happy to share the case study if useful.\n\nMESSAGE 3 (Soft Pitch, Day 7):\nHi Marcus — we put together a quick analysis of TechVista's marketing stack vs HashiCorp and Pulumi. Found 3 specific areas where targeted changes could significantly impact your pipeline. Would a 15-min call be worth your time to walk through it?`,

            auditPitch: `TECHVISTA SOLUTIONS — GROWTH AUDIT SUMMARY\n\nTHE REVENUE PROBLEM\nTechVista is currently leaking an estimated $180K–$420K/year through conversion, SEO, and marketing automation gaps. Despite strong product-market fit and Series B momentum, the marketing infrastructure is not keeping pace with growth.\n\nCRITICAL FINDINGS\n\n1. Conversion System Failure (Score: 42/100)\nPrimary CTA is below fold on 60% of pages. No social proof near conversion points. Lead capture is limited to one contact form. Impact: $60K–$120K/year.\n\n2. SEO Infrastructure Gap (Score: 38/100)\nCore landing pages average 280 words — well below competitive threshold. No blog strategy (4 posts in 12 months). Missing structured data for SERP features. Impact: $40K–$100K/year.\n\n3. Zero Post-Visit Nurturing\nNo marketing automation, lead scoring, or retargeting. Every visitor who doesn't convert immediately is lost. Impact: $50K–$100K/year.\n\nNEXT STEPS\nWe're offering TechVista a complimentary deep-dive audit that covers:\n\n✔ Full conversion funnel analysis with heatmap data\n✔ SEO competitive gap analysis vs HashiCorp, Pulumi, Env0\n✔ Marketing automation architecture recommendation\n✔ 90-day quick-win roadmap with projected ROI\n\nThis audit typically takes 5 business days and is valued at $8,000.`,

            proposalOutline: `PROPOSAL: TECHVISTA SOLUTIONS — GROWTH ACCELERATION PARTNERSHIP\n\n1. EXECUTIVE SUMMARY\nTechVista has achieved strong product-market fit but is underinvesting in acquisition infrastructure. An estimated $180K–$420K/year is being lost through conversion gaps, SEO weaknesses, and absent marketing automation. This proposal outlines a phased engagement to close these gaps and accelerate pipeline growth.\n\n2. SCOPE OF WORK\n\nPhase 1: Quick Wins (Weeks 1-4) — $35K\n• CTA optimization & A/B testing framework\n• Lead capture deployment on all content pages\n• Google Analytics 4 + conversion tracking setup\n\nPhase 2: Foundation (Weeks 5-12) — $75K\n• Website redesign (marketing pages)\n• SEO content strategy + first 10 pillar pages\n• Marketing automation setup (HubSpot)\n\nPhase 3: Scale (Months 4-6) — $60K\n• Paid acquisition campaigns\n• Retargeting infrastructure\n• Case study library development\n\n3. DELIVERABLES\n• Redesigned marketing website (Next.js)\n• 20 SEO-optimized content pages\n• Full HubSpot automation with lead scoring\n• Monthly performance reporting dashboard\n\n4. TIMELINE: 6 months\n\n5. INVESTMENT: $170K total ($28K/month avg)\n   Expected ROI: 3-5x within 12 months\n\n6. WHY US\n• Specialized in B2B SaaS infrastructure companies\n• Proven results with similar cloud/DevOps companies\n• Combined marketing + engineering capabilities`,

            whatsappDM: `Hey! 👋 Quick one — I was checking out TechVista's website and noticed something interesting.\n\nYour cloud orchestration product looks solid but the pricing page doesn't have a competitive comparison section. Evaluators are likely bouncing to compare HashiCorp/Pulumi instead of converting right there.\n\nWe recently helped a similar B2B SaaS company add interactive ROI calculators + competitive comparisons — they saw a 40% bump in pricing page conversions in 90 days.\n\nWould you be up for a quick 10-min call this week? Happy to share the exact playbook. No pitch, just useful insights 🤝`
        };
        return content[type] || 'No demo content available for this type.';
    }

    // ===== PDF & JSON EXPORT =====
    function downloadPDF() {
        if (!currentProfile) { showError('No profile data. Analyze a website first.'); return; }
        try {
            window.generateCompanyProfilePDF(currentProfile);
            els.downloadPdf.innerHTML = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20,6 9,17 4,12"/></svg> Downloaded ✓';
            setTimeout(() => {
                els.downloadPdf.innerHTML = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7,10 12,15 17,10"/><line x1="12" y1="15" x2="12" y2="3"/></svg> Download Full Report';
            }, 2000);
        } catch (e) { showError('PDF failed: ' + e.message); }
    }

    function exportJSON() {
        if (!currentProfile) { showError('No profile data. Analyze a website first.'); return; }
        try {
            const jsonStr = JSON.stringify(currentProfile, null, 2);
            const blob = new Blob([jsonStr], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            const safeName = (currentProfile.companyName || 'company').replace(/[^a-zA-Z0-9]/g, '_').substring(0, 30);
            a.href = url;
            a.download = `${safeName}_Intelligence_Report.json`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);

            els.exportJson.innerHTML = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20,6 9,17 4,12"/></svg> Exported ✓';
            setTimeout(() => {
                els.exportJson.innerHTML = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14,2 14,8 20,8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg> Export JSON';
            }, 2000);
        } catch (e) { showError('JSON export failed: ' + e.message); }
    }

    // ===== UI HELPERS =====
    function setLoading(on) {
        const t = els.analyzeBtn.querySelector('.btn-text-sm');
        const l = els.analyzeBtn.querySelector('.btn-loader');
        t.style.display = on ? 'none' : 'flex';
        l.style.display = on ? 'flex' : 'none';
        els.analyzeBtn.disabled = on;
        els.demoBtn.disabled = on;
    }

    function showProgress(text, pct) {
        els.progressArea.style.display = 'block';
        els.progressText.textContent = text;
        els.progressFill.style.width = `${pct}%`;
    }
    function hideProgress() { els.progressArea.style.display = 'none'; els.progressFill.style.width = '0%'; }
    function showError(msg) { els.errorArea.style.display = 'block'; els.errorText.textContent = msg; }
    function hideError() { els.errorArea.style.display = 'none'; }
    function hideResults() { els.resultsArea.style.display = 'none'; }

    function resetUI() {
        hideResults(); hideError(); hideProgress();
        els.actionCard.style.display = 'block';
        els.siteBadge.style.display = 'flex';
        els.salesModal.classList.remove('open');
        currentProfile = null;
        isDemoMode = false;
        updateRateLimitBadge();
    }

    function scoreColorClass(s) { return s >= 75 ? 'score-green' : s >= 40 ? 'score-amber' : 'score-red'; }
    function scoreFillClass(s) { return s >= 75 ? 'fill-green' : s >= 40 ? 'fill-amber' : 'fill-red'; }
    function scoreGaugeClass(s) { return s >= 75 ? 'gauge-green' : s >= 40 ? 'gauge-amber' : 'gauge-red'; }
    function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

    document.addEventListener('DOMContentLoaded', init);
})();
